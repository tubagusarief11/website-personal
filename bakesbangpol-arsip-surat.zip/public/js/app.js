/* BAKESBANGPOL KAB SERANG - perilaku halaman (tanpa build tool) */
(function () {
  'use strict';

  var root = document.documentElement;

  /* ---------- Tema terang / gelap ---------- */
  function updateThemeIcon() {
    var dark = root.getAttribute('data-bs-theme') === 'dark';
    document.querySelectorAll('[data-theme-icon]').forEach(function (i) {
      i.className = 'bi ' + (dark ? 'bi-sun' : 'bi-moon-stars');
    });
    document.querySelectorAll('[data-theme-toggle]').forEach(function (b) {
      b.setAttribute('aria-label', dark ? 'Ganti ke mode terang' : 'Ganti ke mode gelap');
      b.setAttribute('title', dark ? 'Mode terang' : 'Mode gelap');
    });
  }

  function setTheme(t) {
    root.setAttribute('data-bs-theme', t);
    try { localStorage.setItem('bkp-theme', t); } catch (e) { /* abaikan */ }
    updateThemeIcon();
  }

  document.addEventListener('click', function (e) {
    if (e.target.closest('[data-theme-toggle]')) {
      setTheme(root.getAttribute('data-bs-theme') === 'dark' ? 'light' : 'dark');
    }
    if (e.target.closest('[data-nav-toggle]')) {
      document.body.classList.toggle('nav-open');
    }
    if (e.target.closest('[data-nav-close]')) {
      document.body.classList.remove('nav-open');
    }
  });
  updateThemeIcon();

  /* ---------- Konfirmasi sebelum aksi berbahaya ---------- */
  document.addEventListener('submit', function (e) {
    var f = e.target;
    if (f.matches && f.matches('form[data-confirm]')) {
      if (!window.confirm(f.getAttribute('data-confirm'))) {
        e.preventDefault();
      }
    }
  });

  /* ---------- Tampilkan elemen sesuai pilihan (select) ---------- */
  function bindShowWhen(select) {
    var scope = select.closest('form') || document;
    function apply() {
      scope.querySelectorAll('[data-show-when]').forEach(function (el) {
        var show = el.getAttribute('data-show-when') === select.value;
        el.classList.toggle('d-none', !show);
        el.querySelectorAll('input, select, textarea').forEach(function (i) { i.disabled = !show; });
      });
    }
    select.addEventListener('change', apply);
    apply();
  }
  document.querySelectorAll('select[data-controls-show]').forEach(bindShowWhen);

  /* ---------- Pratinjau foto ---------- */
  document.querySelectorAll('input[type=file][data-preview]').forEach(function (inp) {
    inp.addEventListener('change', function () {
      var img = document.querySelector(inp.getAttribute('data-preview'));
      if (!img || !inp.files || !inp.files[0]) { return; }
      img.src = URL.createObjectURL(inp.files[0]);
      img.classList.remove('d-none');
    });
  });

  /* ---------- Form surat ---------- */
  var form = document.getElementById('form-surat');
  if (!form) { return; }

  var kategori = form.querySelector('[name=kategori_id]');
  var secPenelitian = document.getElementById('sec-penelitian');
  var secAudiensi = document.getElementById('sec-audiensi');
  var lblPihak = document.getElementById('lbl-pihak');
  var pad = null;
  var canvas = document.getElementById('sigpad');

  function jenisAktif() {
    var r = form.querySelector('input[name=jenis]:checked');
    if (r) { return r.value; }
    var h = form.querySelector('input[type=hidden][name=jenis]');
    return h ? h.value : 'masuk';
  }

  function slugAktif() {
    if (!kategori || kategori.selectedIndex < 0) { return ''; }
    var opt = kategori.options[kategori.selectedIndex];
    return opt ? (opt.getAttribute('data-slug') || '') : '';
  }

  function toggle(el, show) {
    if (!el) { return; }
    el.classList.toggle('d-none', !show);
    el.querySelectorAll('input, select, textarea').forEach(function (i) { i.disabled = !show; });
  }

  function resizeSig() {
    if (!canvas || !pad) { return; }
    var data = pad.toData();
    var ratio = Math.max(window.devicePixelRatio || 1, 1);
    var w = canvas.offsetWidth;
    if (!w) { return; }
    canvas.width = w * ratio;
    canvas.height = 170 * ratio;
    canvas.getContext('2d').scale(ratio, ratio);
    pad.clear();
    pad.fromData(data);
  }

  function refresh() {
    var jenis = jenisAktif();
    var slug = slugAktif();
    var masuk = jenis === 'masuk';

    toggle(secPenelitian, masuk && slug === 'izin-penelitian');
    toggle(secAudiensi, masuk && slug === 'izin-audiensi');

    form.querySelectorAll('.only-masuk').forEach(function (el) { toggle(el, masuk); });
    form.querySelectorAll('.only-keluar').forEach(function (el) { toggle(el, !masuk); });

    if (lblPihak) { lblPihak.textContent = masuk ? 'Pengirim (instansi / organisasi / nama)' : 'Tujuan surat'; }

    var jj = document.getElementById('judul-halaman-jenis');
    if (jj) { jj.textContent = masuk ? 'surat masuk' : 'surat keluar'; }

    if (masuk && slug === 'izin-penelitian') { setTimeout(resizeSig, 30); }
  }

  form.querySelectorAll('input[name=jenis]').forEach(function (r) { r.addEventListener('change', refresh); });
  if (kategori) { kategori.addEventListener('change', refresh); }

  /* Isi otomatis pengirim dari nama universitas (hanya bila pengirim masih kosong) */
  var pihak = form.querySelector('[name=pihak]');
  var univ = form.querySelector('[name=universitas]');
  if (pihak && univ) {
    pihak.addEventListener('input', function () { pihak.dataset.auto = ''; });
    univ.addEventListener('input', function () {
      if (!pihak.value || pihak.dataset.auto === '1') {
        pihak.value = univ.value;
        pihak.dataset.auto = '1';
      }
    });
  }

  /* Papan tanda tangan */
  if (canvas && window.SignaturePad) {
    pad = new SignaturePad(canvas, { minWidth: 0.7, maxWidth: 2.2, penColor: '#0b2250' });
    window.addEventListener('resize', resizeSig);
    var clear = document.querySelector('[data-sig-clear]');
    if (clear) { clear.addEventListener('click', function () { pad.clear(); }); }
    form.addEventListener('submit', function () {
      var hid = document.getElementById('ttd_data');
      if (hid && !pad.isEmpty() && !hid.disabled) { hid.value = pad.toDataURL('image/png'); }
    });
  }

  refresh();
})();
