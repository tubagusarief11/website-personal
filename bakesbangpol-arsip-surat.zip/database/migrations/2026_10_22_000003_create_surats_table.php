<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('surats', function (Blueprint $table) {
            $table->id();
            $table->string('jenis', 10)->index();                    // masuk | keluar
            $table->foreignId('kategori_id')->constrained('kategoris');
            $table->string('nomor_surat', 150)->index();
            $table->string('nomor_agenda', 50)->nullable();
            $table->date('tanggal_surat');
            $table->date('tanggal_terima')->nullable();               // khusus surat masuk
            $table->string('pihak', 200);                             // pengirim (masuk) / tujuan (keluar)
            $table->string('jenis_pihak', 20)->nullable();            // instansi | mahasiswa | ormas | lainnya
            $table->string('kontak', 100)->nullable();
            $table->string('perihal', 500);
            $table->string('sifat', 20)->default('biasa');            // biasa | penting | segera
            $table->text('catatan')->nullable();

            $table->string('file_path')->nullable();
            $table->string('file_name')->nullable();
            $table->string('file_mime', 100)->nullable();
            $table->unsignedBigInteger('file_size')->nullable();

            $table->string('status', 20)->default('belum_ditindak')->index(); // belum_ditindak | sudah_ditindak
            $table->foreignId('surat_asal_id')->nullable()->constrained('surats')->nullOnDelete(); // surat balasan -> surat asal

            // disiapkan untuk versi berikutnya (alur disposisi / generate surat dari template)
            $table->string('sumber_input', 20)->default('manual');
            $table->unsignedBigInteger('template_id')->nullable();

            $table->foreignId('created_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamps();
            $table->softDeletes();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('surats');
    }
};
