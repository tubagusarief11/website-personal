<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('izin_penelitians', function (Blueprint $table) {
            $table->id();
            $table->foreignId('surat_id')->unique()->constrained('surats')->cascadeOnDelete();
            $table->string('nama_mahasiswa');
            $table->string('nim', 50)->nullable();
            $table->string('universitas');
            $table->string('prodi')->nullable();
            $table->text('judul_penelitian')->nullable();
            $table->string('lokasi_penelitian')->nullable();
            $table->string('penanggung_jawab');
            $table->date('masa_mulai')->nullable();
            $table->date('masa_selesai')->nullable();
            $table->string('foto_path')->nullable();
            $table->string('ttd_path')->nullable();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('izin_penelitians');
    }
};
