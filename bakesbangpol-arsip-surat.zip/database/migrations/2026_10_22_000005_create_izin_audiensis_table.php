<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('izin_audiensis', function (Blueprint $table) {
            $table->id();
            $table->foreignId('surat_id')->unique()->constrained('surats')->cascadeOnDelete();
            $table->string('nama_pihak');
            $table->string('jenis_pihak', 20);                        // ormas | mahasiswa | instansi | lainnya
            $table->text('tujuan')->nullable();
            $table->date('tanggal_rencana')->nullable();
            $table->unsignedInteger('jumlah_peserta')->nullable();
            $table->string('penanggung_jawab')->nullable();
            $table->string('kontak', 100)->nullable();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('izin_audiensis');
    }
};
