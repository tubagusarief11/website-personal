<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('tindak_lanjuts', function (Blueprint $table) {
            $table->id();
            $table->foreignId('surat_id')->unique()->constrained('surats')->cascadeOnDelete();
            $table->string('hasil', 20);                               // dibalas | dialihkan | diizinkan | ditolak | diarsipkan
            $table->date('tanggal_tindakan');
            $table->text('keterangan')->nullable();
            $table->string('instansi_tujuan')->nullable();             // diisi bila hasil = dialihkan
            $table->foreignId('validator_id')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('tindak_lanjuts');
    }
};
