<?php

namespace Database\Seeders;

use App\Models\Kategori;
use App\Models\User;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        // Kategori surat
        $kategori = [
            ['nama' => 'Izin Penelitian Mahasiswa', 'slug' => Kategori::PENELITIAN, 'urutan' => 1,
                'deskripsi' => 'Surat izin penelitian dari mahasiswa / perguruan tinggi'],
            ['nama' => 'Izin Audiensi / Kunjungan', 'slug' => Kategori::AUDIENSI, 'urutan' => 2,
                'deskripsi' => 'Izin audiensi atau kunjungan ormas, mahasiswa, dan instansi ke BAKESBANGPOL'],
            ['nama' => 'Lainnya', 'slug' => Kategori::LAINNYA, 'urutan' => 3,
                'deskripsi' => 'Surat di luar kategori di atas'],
        ];

        foreach ($kategori as $k) {
            Kategori::updateOrCreate(['slug' => $k['slug']], $k);
        }

        // Akun awal -> WAJIB diganti passwordnya setelah login pertama
        User::updateOrCreate(
            ['email' => 'admin@bakesbangpol.local'],
            [
                'name' => 'Administrator',
                'password' => 'Admin#12345',
                'role' => User::ROLE_ADMIN,
                'is_active' => true,
                'jabatan' => 'Administrator Sistem',
            ]
        );

        User::updateOrCreate(
            ['email' => 'operator@bakesbangpol.local'],
            [
                'name' => 'Operator Wasnas',
                'password' => 'Operator#12345',
                'role' => User::ROLE_OPERATOR,
                'is_active' => true,
                'jabatan' => 'Bidang Kewaspadaan Nasional',
            ]
        );
    }
}
