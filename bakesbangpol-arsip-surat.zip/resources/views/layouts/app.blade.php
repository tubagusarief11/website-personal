<!doctype html>
<html lang="id" data-bs-theme="light">
<head>
    @include('partials.head', ['judul' => trim($__env->yieldContent('title', 'Dashboard'))])
</head>
<body>
@php
    $q = request();
    $diIndeks = $q->routeIs('surat.index');
    $menuSemua = $diIndeks && ! $q->filled('jenis') && ! $q->filled('kategori');
    $menuMasuk = $diIndeks && $q->query('jenis') === 'masuk' && ! $q->filled('kategori');
    $menuKeluar = $diIndeks && $q->query('jenis') === 'keluar' && ! $q->filled('kategori');
@endphp

<div class="app-shell">
    <aside class="sidebar" id="sidebar" aria-label="Menu utama">
        <div class="sidebar-brand">
            <a href="{{ route('dashboard') }}" class="brand-plate" aria-label="Beranda BAKESBANGPOL Kab. Serang">
                <img src="{{ asset('img/logo-bakesbangpol.png') }}" alt="Badan Kesatuan Bangsa dan Politik, Pemerintah Kabupaten Serang">
            </a>
            <div class="brand-app">
                <strong>Sistem Arsip Surat</strong>
                BAKESBANGPOL KAB SERANG
            </div>
        </div>

        <nav class="sidebar-scroll">
            <a href="{{ route('dashboard') }}" class="side-link {{ $q->routeIs('dashboard') ? 'active' : '' }}">
                <i class="bi bi-grid-1x2"></i> Dashboard
            </a>

            <div class="side-group">Arsip surat</div>
            <a href="{{ route('surat.index') }}" class="side-link {{ $menuSemua ? 'active' : '' }}">
                <i class="bi bi-archive"></i> Semua surat
            </a>
            <a href="{{ route('surat.index', ['jenis' => 'masuk']) }}" class="side-link {{ $menuMasuk ? 'active' : '' }}">
                <i class="bi bi-box-arrow-in-down"></i> Surat masuk
            </a>
            <a href="{{ route('surat.index', ['jenis' => 'keluar']) }}" class="side-link {{ $menuKeluar ? 'active' : '' }}">
                <i class="bi bi-box-arrow-up"></i> Surat keluar
            </a>

            <div class="side-group">Per kategori</div>
            @foreach ($kategoriMenu as $kat)
                <a href="{{ route('surat.index', ['kategori' => $kat->slug]) }}"
                   class="side-link {{ $diIndeks && $q->query('kategori') === $kat->slug ? 'active' : '' }}">
                    <i class="bi {{ $kat->ikon }}"></i> {{ $kat->nama }}
                    @if ($kat->belum_count > 0)
                        <span class="side-badge" title="Surat masuk belum ditindak">{{ $kat->belum_count }}</span>
                    @endif
                </a>
            @endforeach

            <div class="side-group">Catat surat</div>
            <a href="{{ route('surat.create', ['jenis' => 'masuk']) }}"
               class="side-link {{ $q->routeIs('surat.create') && $q->query('jenis', 'masuk') === 'masuk' ? 'active' : '' }}">
                <i class="bi bi-plus-circle"></i> Surat masuk baru
            </a>
            <a href="{{ route('surat.create', ['jenis' => 'keluar']) }}"
               class="side-link {{ $q->routeIs('surat.create') && $q->query('jenis') === 'keluar' ? 'active' : '' }}">
                <i class="bi bi-plus-circle-dotted"></i> Surat keluar baru
            </a>

            @if (auth()->user()->isAdmin())
                <div class="side-group">Administrasi</div>
                <a href="{{ route('admin.users.index') }}" class="side-link {{ $q->routeIs('admin.users.*') ? 'active' : '' }}">
                    <i class="bi bi-people"></i> Pengguna
                </a>
            @endif
        </nav>

        <div class="sidebar-foot">
            Badan Kesatuan Bangsa dan Politik<br>Pemerintah Kabupaten Serang
        </div>
    </aside>
    <div class="sidebar-scrim" data-nav-close></div>

    <div class="main">
        <header class="topbar">
            <button type="button" class="icon-btn only-mobile" data-nav-toggle aria-label="Buka menu">
                <i class="bi bi-list fs-5"></i>
            </button>
            <p class="topbar-title"><strong>BAKESBANGPOL</strong> Kab. Serang</p>

            <div class="ms-auto d-flex align-items-center gap-2">
                <button type="button" class="icon-btn" data-theme-toggle aria-label="Ganti tema">
                    <i class="bi bi-moon-stars" data-theme-icon></i>
                </button>

                <div class="dropdown">
                    <button class="user-chip" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <span class="avatar">{{ auth()->user()->inisial }}</span>
                        <span class="who">
                            <b>{{ auth()->user()->name }}</b>
                            <span>{{ auth()->user()->role_label }}</span>
                        </span>
                        <i class="bi bi-chevron-down small"></i>
                    </button>
                    <ul class="dropdown-menu dropdown-menu-end">
                        <li class="px-3 py-2 small text-muted">{{ auth()->user()->email }}</li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item" href="{{ route('password.edit') }}"><i class="bi bi-key me-2"></i>Ubah password</a></li>
                        <li>
                            <form method="POST" action="{{ route('logout') }}">
                                @csrf
                                <button type="submit" class="dropdown-item"><i class="bi bi-box-arrow-right me-2"></i>Keluar</button>
                            </form>
                        </li>
                    </ul>
                </div>
            </div>
        </header>

        <main class="content">
            @if (session('success'))
                <div class="alert alert-success d-flex align-items-start gap-2" role="status">
                    <i class="bi bi-check-circle-fill"></i><div>{{ session('success') }}</div>
                </div>
            @endif
            @if ($errors->has('hapus'))
                <div class="alert alert-danger" role="alert">{{ $errors->first('hapus') }}</div>
            @endif

            @yield('content')
        </main>

        <footer class="footer">
            &copy; {{ date('Y') }} Badan Kesatuan Bangsa dan Politik Kabupaten Serang. Dokumen di sistem ini bersifat internal.
        </footer>
    </div>
</div>

<script src="{{ asset('vendor/bootstrap/js/bootstrap.bundle.min.js') }}"></script>
@stack('scripts')
<script src="{{ asset('js/app.js') }}"></script>
</body>
</html>
