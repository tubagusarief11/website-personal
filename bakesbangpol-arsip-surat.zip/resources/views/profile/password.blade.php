@extends('layouts.app')

@section('title', 'Ubah Password')

@section('content')
    <div class="page-head">
        <div>
            <h1>Ubah password</h1>
            <p>Gunakan minimal 8 karakter. Ganti password bawaan sesegera mungkin.</p>
        </div>
    </div>

    <div class="card" style="max-width: 520px">
        <div class="card-body">
            <form method="POST" action="{{ route('password.update') }}">
                @csrf @method('PUT')

                <div class="mb-3">
                    <label class="form-label req" for="password_lama">Password lama</label>
                    <input type="password" name="password_lama" id="password_lama" class="form-control @error('password_lama') is-invalid @enderror" autocomplete="current-password">
                    @error('password_lama') <div class="invalid-feedback">{{ $message }}</div> @enderror
                </div>
                <div class="mb-3">
                    <label class="form-label req" for="password">Password baru</label>
                    <input type="password" name="password" id="password" class="form-control @error('password') is-invalid @enderror" autocomplete="new-password">
                    @error('password') <div class="invalid-feedback">{{ $message }}</div> @enderror
                </div>
                <div class="mb-4">
                    <label class="form-label req" for="password_confirmation">Ulangi password baru</label>
                    <input type="password" name="password_confirmation" id="password_confirmation" class="form-control" autocomplete="new-password">
                </div>
                <button class="btn btn-primary"><i class="bi bi-check2"></i> Simpan password</button>
            </form>
        </div>
    </div>
@endsection
