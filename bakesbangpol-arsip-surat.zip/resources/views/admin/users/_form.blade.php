@php $edit = $user->exists; @endphp

@if ($errors->any())
    <div class="alert alert-danger" role="alert">
        <ul class="mb-0 ps-3">@foreach ($errors->all() as $pesan)<li>{{ $pesan }}</li>@endforeach</ul>
    </div>
@endif

<form method="POST" action="{{ $edit ? route('admin.users.update', $user) : route('admin.users.store') }}" class="card" style="max-width: 640px">
    @csrf
    @if ($edit) @method('PUT') @endif
    <div class="card-body">
        <div class="row g-3">
            <div class="col-md-6">
                <label class="form-label req" for="name">Nama lengkap</label>
                <input type="text" name="name" id="name" value="{{ old('name', $user->name) }}" class="form-control">
            </div>
            <div class="col-md-6">
                <label class="form-label req" for="email">Email</label>
                <input type="email" name="email" id="email" value="{{ old('email', $user->email) }}" class="form-control" autocomplete="off">
            </div>
            <div class="col-md-6">
                <label class="form-label" for="jabatan">Jabatan / bidang</label>
                <input type="text" name="jabatan" id="jabatan" value="{{ old('jabatan', $user->jabatan) }}" class="form-control">
            </div>
            <div class="col-md-6">
                <label class="form-label req" for="role">Peran</label>
                <select name="role" id="role" class="form-select">
                    @foreach (\App\Models\User::ROLES as $k => $lbl)
                        <option value="{{ $k }}" @selected(old('role', $user->role) === $k)>{{ $lbl }}</option>
                    @endforeach
                </select>
            </div>
            <div class="col-md-6">
                <label class="form-label {{ $edit ? '' : 'req' }}" for="password">{{ $edit ? 'Password baru' : 'Password' }}</label>
                <input type="password" name="password" id="password" class="form-control" autocomplete="new-password">
                <div class="form-text">{{ $edit ? 'Kosongkan jika tidak ingin mengganti.' : 'Minimal 8 karakter.' }}</div>
            </div>
            <div class="col-md-6">
                <label class="form-label" for="password_confirmation">Ulangi password</label>
                <input type="password" name="password_confirmation" id="password_confirmation" class="form-control" autocomplete="new-password">
            </div>
            <div class="col-12">
                <input type="hidden" name="is_active" value="0">
                <div class="form-check form-switch">
                    <input class="form-check-input" type="checkbox" role="switch" name="is_active" id="is_active" value="1" @checked(old('is_active', $user->is_active ?? true))>
                    <label class="form-check-label" for="is_active">Akun aktif (bisa masuk ke sistem)</label>
                </div>
            </div>
        </div>
    </div>
    <div class="card-footer d-flex gap-2" style="background: var(--surface-2); border-color: var(--line)">
        <button class="btn btn-primary"><i class="bi bi-check2"></i> {{ $edit ? 'Simpan perubahan' : 'Tambah pengguna' }}</button>
        <a href="{{ route('admin.users.index') }}" class="btn btn-light-line">Batal</a>
    </div>
</form>
