@extends('layouts.app')

@section('title', 'Ubah Pengguna')

@section('content')
    <div class="page-head"><div><h1>Ubah pengguna</h1><p>{{ $user->email }}</p></div></div>
    @include('admin.users._form')
@endsection
