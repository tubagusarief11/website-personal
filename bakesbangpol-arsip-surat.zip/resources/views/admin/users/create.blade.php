@extends('layouts.app')

@section('title', 'Tambah Pengguna')

@section('content')
    <div class="page-head"><div><h1>Tambah pengguna</h1></div></div>
    @include('admin.users._form')
@endsection
