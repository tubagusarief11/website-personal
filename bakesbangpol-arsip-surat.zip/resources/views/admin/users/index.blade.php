@extends('layouts.app')

@section('title', 'Pengguna')

@section('content')
    <div class="page-head">
        <div>
            <h1>Pengguna</h1>
            <p>Kelola akun yang boleh masuk ke sistem. Admin bisa menghapus surat dan mengelola pengguna; Operator mencatat dan memvalidasi surat.</p>
        </div>
        <a href="{{ route('admin.users.create') }}" class="btn btn-primary"><i class="bi bi-person-plus"></i> Tambah pengguna</a>
    </div>

    <div class="table-wrap">
        <div class="table-responsive">
            <table class="table table-hover align-middle">
                <thead>
                    <tr>
                        <th>Nama</th>
                        <th>Email</th>
                        <th>Peran</th>
                        <th>Status</th>
                        <th class="text-end">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($users as $u)
                        <tr>
                            <td>
                                <span class="fw-semibold">{{ $u->name }}</span>
                                @if ($u->id === auth()->id()) <span class="pill pill-plain ms-1">Anda</span> @endif
                                @if ($u->jabatan) <span class="muted-s d-block">{{ $u->jabatan }}</span> @endif
                            </td>
                            <td>{{ $u->email }}</td>
                            <td><span class="pill {{ $u->isAdmin() ? 'pill-info' : 'pill-plain' }}">{{ $u->role_label }}</span></td>
                            <td>
                                @if ($u->is_active) <span class="pill pill-ok">Aktif</span> @else <span class="pill pill-bad">Nonaktif</span> @endif
                            </td>
                            <td class="text-end text-nowrap">
                                <a href="{{ route('admin.users.edit', $u) }}" class="btn btn-sm btn-light-line"><i class="bi bi-pencil"></i> Ubah</a>
                                @if ($u->id !== auth()->id())
                                    <form method="POST" action="{{ route('admin.users.destroy', $u) }}" class="d-inline" data-confirm="Hapus pengguna {{ $u->name }}?">
                                        @csrf @method('DELETE')
                                        <button class="btn btn-sm btn-outline-danger" aria-label="Hapus {{ $u->name }}"><i class="bi bi-trash"></i></button>
                                    </form>
                                @endif
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
        @if ($users->hasPages())
            <div class="p-3 border-top" style="border-color: var(--line) !important">{{ $users->links() }}</div>
        @endif
    </div>
@endsection
