@php
    /** @var \App\Models\Surat $surat */
@endphp
@if ($surat->jenis === 'keluar')
    <span class="pill pill-info">Surat keluar</span>
@elseif ($surat->status === 'sudah_ditindak')
    @php
        $hasil = $surat->tindakLanjut?->hasil;
        $kelas = match ($hasil) {
            'ditolak' => 'pill-bad',
            'dialihkan' => 'pill-info',
            default => 'pill-ok',
        };
    @endphp
    <span class="pill {{ $kelas }}">Sudah ditindak</span>
@else
    <span class="pill pill-warn">Belum ditindak</span>
@endif
