<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="csrf-token" content="{{ csrf_token() }}">
<title>{{ $judul ?? 'Sistem Arsip Surat' }} | BAKESBANGPOL KAB SERANG</title>
<link rel="icon" type="image/png" href="{{ asset('img/favicon.png') }}">

{{-- Pasang tema sebelum halaman digambar supaya tidak berkedip --}}
<script>
    (function () {
        try {
            var t = localStorage.getItem('bkp-theme');
            document.documentElement.setAttribute('data-bs-theme', t === 'dark' ? 'dark' : 'light');
        } catch (e) {
            document.documentElement.setAttribute('data-bs-theme', 'light');
        }
    })();
</script>

<link rel="stylesheet" href="{{ asset('vendor/bootstrap/css/bootstrap.min.css') }}">
<link rel="stylesheet" href="{{ asset('vendor/bootstrap-icons/bootstrap-icons.min.css') }}">
<link rel="stylesheet" href="{{ asset('css/app.css') }}">
