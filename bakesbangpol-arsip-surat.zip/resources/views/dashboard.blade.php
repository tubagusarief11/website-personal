@extends('layouts.app')

@section('title', 'Dashboard')

@section('content')
    <div class="page-head">
        <div>
            <h1>Dashboard</h1>
            <p>Ringkasan arsip surat BAKESBANGPOL Kab. Serang per {{ now()->translatedFormat('j F Y') }}.</p>
        </div>
        <div class="d-flex gap-2 no-print">
            <a href="{{ route('surat.create', ['jenis' => 'masuk']) }}" class="btn btn-primary">
                <i class="bi bi-plus-lg"></i> Catat surat masuk
            </a>
            <a href="{{ route('surat.create', ['jenis' => 'keluar']) }}" class="btn btn-light-line">
                <i class="bi bi-plus-lg"></i> Surat keluar
            </a>
        </div>
    </div>

    <div class="row g-3 mb-4">
        <div class="col-6 col-xl-3">
            <a href="{{ route('surat.index', ['jenis' => 'masuk', 'status' => 'belum_ditindak']) }}" class="stat warn text-decoration-none text-reset">
                <span class="ic"><i class="bi bi-hourglass-split"></i></span>
                <span><span class="num d-block">{{ $ringkas['belum'] }}</span><span class="lbl">Surat masuk belum ditindak</span></span>
            </a>
        </div>
        <div class="col-6 col-xl-3">
            <div class="stat">
                <span class="ic"><i class="bi bi-archive"></i></span>
                <span><span class="num d-block">{{ $ringkas['total'] }}</span><span class="lbl">Total surat di arsip</span></span>
            </div>
        </div>
        <div class="col-6 col-xl-3">
            <div class="stat">
                <span class="ic"><i class="bi bi-box-arrow-in-down"></i></span>
                <span><span class="num d-block">{{ $ringkas['masuk_bulan_ini'] }}</span><span class="lbl">Surat masuk bulan ini</span></span>
            </div>
        </div>
        <div class="col-6 col-xl-3">
            <div class="stat">
                <span class="ic"><i class="bi bi-box-arrow-up"></i></span>
                <span><span class="num d-block">{{ $ringkas['keluar_bulan_ini'] }}</span><span class="lbl">Surat keluar bulan ini</span></span>
            </div>
        </div>
    </div>

    <div class="row g-4">
        <div class="col-lg-8">
            <h2 class="section-title"><i class="bi bi-hourglass-split"></i> Menunggu tindakan</h2>
            <div class="table-wrap mb-4">
                @if ($antrean->isEmpty())
                    <div class="p-4 text-center text-muted">
                        <i class="bi bi-check2-circle fs-3 d-block mb-1"></i>
                        Tidak ada surat masuk yang menunggu tindakan.
                    </div>
                @else
                    <div class="table-responsive">
                        <table class="table table-hover align-middle">
                            <thead>
                                <tr>
                                    <th>Surat</th>
                                    <th>Kategori</th>
                                    <th class="text-end">Menunggu</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($antrean as $s)
                                    @php $hari = $s->menunggu_hari; @endphp
                                    <tr class="{{ $hari > 7 ? 'row-late' : '' }}">
                                        <td>
                                            <a class="perihal" href="{{ route('surat.show', $s) }}">{{ \Illuminate\Support\Str::limit($s->perihal, 90) }}</a>
                                            <span class="muted-s">{{ $s->pihak }} &ndash; {{ $s->nomor_surat }}</span>
                                        </td>
                                        <td><span class="pill pill-plain">{{ $s->kategori->nama }}</span></td>
                                        <td class="text-end">
                                            @if ($hari > 7)
                                                <span class="pill pill-urgent">{{ $hari }} hari</span>
                                            @elseif ($hari === 0)
                                                <span class="muted-s">Hari ini</span>
                                            @else
                                                <span class="muted-s">{{ $hari }} hari</span>
                                            @endif
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                @endif
            </div>

            <h2 class="section-title"><i class="bi bi-clock-history"></i> Surat terbaru di arsip</h2>
            <div class="table-wrap">
                @if ($terbaru->isEmpty())
                    <div class="p-4 text-center text-muted">
                        Arsip masih kosong. Mulai dengan
                        <a href="{{ route('surat.create', ['jenis' => 'masuk']) }}">mencatat surat masuk pertama</a>.
                    </div>
                @else
                    <div class="table-responsive">
                        <table class="table table-hover align-middle">
                            <tbody>
                                @foreach ($terbaru as $s)
                                    <tr>
                                        <td style="width:1%" class="text-nowrap">
                                            <span class="pill {{ $s->jenis === 'masuk' ? 'pill-plain' : 'pill-info' }}">{{ $s->jenis === 'masuk' ? 'Masuk' : 'Keluar' }}</span>
                                        </td>
                                        <td>
                                            <a class="perihal" href="{{ route('surat.show', $s) }}">{{ \Illuminate\Support\Str::limit($s->perihal, 80) }}</a>
                                            <span class="muted-s">{{ $s->pihak }}</span>
                                        </td>
                                        <td class="text-end text-nowrap muted-s">{{ $s->tanggal_surat->translatedFormat('j M Y') }}</td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                @endif
            </div>
        </div>

        <div class="col-lg-4">
            <h2 class="section-title"><i class="bi bi-folder2-open"></i> Per kategori</h2>
            <div class="card mb-4">
                @foreach ($perKategori as $kat)
                    <a href="{{ route('surat.index', ['kategori' => $kat->slug]) }}" class="kat-row">
                        <span class="ic"><i class="bi {{ $kat->ikon }}"></i></span>
                        <span>
                            <span class="nm d-block">{{ $kat->nama }}</span>
                            <span class="ds d-block">{{ $kat->belum_count }} belum ditindak</span>
                        </span>
                        <span class="cnt"><b>{{ $kat->total_count }}</b>surat</span>
                    </a>
                @endforeach
            </div>

            <h2 class="section-title"><i class="bi bi-activity"></i> Aktivitas terakhir</h2>
            <div class="card">
                <div class="card-body">
                    @if ($aktivitas->isEmpty())
                        <p class="text-muted mb-0 small">Belum ada aktivitas.</p>
                    @else
                        <ul class="timeline mb-0">
                            @foreach ($aktivitas as $a)
                                <li>
                                    <div>{{ $a->keterangan ?? $a->aksi }}</div>
                                    <div class="t">{{ $a->user?->name ?? 'Sistem' }} &ndash; {{ $a->created_at->diffForHumans() }}</div>
                                </li>
                            @endforeach
                        </ul>
                    @endif
                </div>
            </div>
        </div>
    </div>
@endsection
