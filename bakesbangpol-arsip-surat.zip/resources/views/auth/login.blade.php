<!doctype html>
<html lang="id" data-bs-theme="light">
<head>
    @include('partials.head', ['judul' => 'Masuk'])
</head>
<body>
<div class="login-wrap">
    <section class="login-side" aria-hidden="false">
        <div>
            <span class="plate">
                <img src="{{ asset('img/logo-bakesbangpol.png') }}" alt="Badan Kesatuan Bangsa dan Politik, Pemerintah Kabupaten Serang">
            </span>
        </div>
        <div>
            <h2>Arsip surat yang tertata dan mudah dicari</h2>
            <p>Simpan salinan surat masuk dan keluar, catat tindak lanjutnya, dan temukan kembali surat kapan pun diperlukan, termasuk saat surat aslinya hilang.</p>
        </div>
        <div class="foot">BAKESBANGPOL KAB SERANG &ndash; hanya untuk pegawai yang berwenang.</div>
    </section>

    <section class="login-main position-relative">
        <div class="login-top">
            <button type="button" class="icon-btn" data-theme-toggle aria-label="Ganti tema">
                <i class="bi bi-moon-stars" data-theme-icon></i>
            </button>
        </div>

        <div class="login-card">
            <h1>Masuk ke sistem</h1>
            <p class="text-muted mb-4">Gunakan akun yang diberikan oleh admin.</p>

            <form method="POST" action="{{ route('login.attempt') }}" novalidate>
                @csrf

                @if ($errors->any())
                    <div class="alert alert-danger" role="alert">{{ $errors->first() }}</div>
                @endif

                <div class="mb-3">
                    <label for="email" class="form-label">Email</label>
                    <input type="text" id="email" name="email" value="{{ old('email') }}"
                           class="form-control form-control-lg" autocomplete="username" autofocus required>
                </div>

                <div class="mb-3">
                    <label for="password" class="form-label">Password</label>
                    <input type="password" id="password" name="password"
                           class="form-control form-control-lg" autocomplete="current-password" required>
                </div>

                <div class="form-check mb-4">
                    <input class="form-check-input" type="checkbox" name="remember" id="remember" value="1">
                    <label class="form-check-label" for="remember">Ingat saya di perangkat ini</label>
                </div>

                <button type="submit" class="btn btn-primary btn-lg w-100">
                    <i class="bi bi-box-arrow-in-right"></i> Masuk
                </button>
            </form>
        </div>
    </section>
</div>

<script src="{{ asset('js/app.js') }}"></script>
</body>
</html>
