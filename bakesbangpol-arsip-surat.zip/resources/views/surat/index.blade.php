@extends('layouts.app')

@section('title', 'Arsip Surat')

@php
    $kategoriAktif = $filter['kategori'] ?? null;
    $judul = match (true) {
        ($filter['jenis'] ?? null) === 'masuk' => 'Surat masuk',
        ($filter['jenis'] ?? null) === 'keluar' => 'Surat keluar',
        default => 'Arsip semua surat',
    };
    $tanpaKategori = array_filter(\Illuminate\Support\Arr::except($filter, ['kategori']));
    $totalSemua = $hitung->sum();
@endphp

@section('content')
    <div class="page-head">
        <div>
            <h1>{{ $judul }}</h1>
            <p>Telusuri salinan surat berdasarkan kategori, status, dan kata kunci.</p>
        </div>
        <div class="d-flex gap-2 no-print">
            <a href="{{ route('surat.create', ['jenis' => 'masuk']) }}" class="btn btn-primary"><i class="bi bi-plus-lg"></i> Surat masuk</a>
            <a href="{{ route('surat.create', ['jenis' => 'keluar']) }}" class="btn btn-light-line"><i class="bi bi-plus-lg"></i> Surat keluar</a>
        </div>
    </div>

    {{-- Tab kategori --}}
    <div class="kat-tabs">
        <a href="{{ route('surat.index', $tanpaKategori) }}" class="kat-tab {{ ! $kategoriAktif ? 'active' : '' }}">
            Semua kategori <span class="n">{{ $totalSemua }}</span>
        </a>
        @foreach ($kategoris as $kat)
            <a href="{{ route('surat.index', $tanpaKategori + ['kategori' => $kat->slug]) }}"
               class="kat-tab {{ $kategoriAktif === $kat->slug ? 'active' : '' }}">
                <i class="bi {{ $kat->ikon }}"></i> {{ $kat->nama }}
                <span class="n">{{ $hitung[$kat->id] ?? 0 }}</span>
            </a>
        @endforeach
    </div>

    {{-- Pencarian & filter --}}
    <form method="GET" action="{{ route('surat.index') }}" class="card mb-3 no-print">
        <div class="card-body">
            @if ($kategoriAktif)
                <input type="hidden" name="kategori" value="{{ $kategoriAktif }}">
            @endif
            <div class="row g-2 align-items-end">
                <div class="col-lg-4">
                    <label class="form-label" for="q">Cari</label>
                    <input type="search" id="q" name="q" value="{{ $filter['q'] ?? '' }}" class="form-control"
                           placeholder="Nomor, perihal, pengirim, nama mahasiswa, universitas">
                </div>
                <div class="col-6 col-lg-2">
                    <label class="form-label" for="jenis">Jenis</label>
                    <select id="jenis" name="jenis" class="form-select">
                        <option value="">Semua</option>
                        @foreach (\App\Models\Surat::JENIS as $k => $v)
                            <option value="{{ $k }}" @selected(($filter['jenis'] ?? '') === $k)>{{ $v }}</option>
                        @endforeach
                    </select>
                </div>
                <div class="col-6 col-lg-2">
                    <label class="form-label" for="status">Status</label>
                    <select id="status" name="status" class="form-select">
                        <option value="">Semua</option>
                        @foreach (\App\Models\Surat::STATUS as $k => $v)
                            <option value="{{ $k }}" @selected(($filter['status'] ?? '') === $k)>{{ $v }}</option>
                        @endforeach
                    </select>
                </div>
                <div class="col-6 col-lg-2">
                    <label class="form-label" for="tahun">Tahun</label>
                    <select id="tahun" name="tahun" class="form-select">
                        <option value="">Semua</option>
                        @foreach ($daftarTahun as $t)
                            <option value="{{ $t }}" @selected((string) ($filter['tahun'] ?? '') === (string) $t)>{{ $t }}</option>
                        @endforeach
                    </select>
                </div>
                <div class="col-6 col-lg-2 d-flex gap-2">
                    <button class="btn btn-primary flex-fill" type="submit"><i class="bi bi-search"></i> Cari</button>
                    <a href="{{ route('surat.index', $kategoriAktif ? ['kategori' => $kategoriAktif] : []) }}" class="btn btn-light-line" title="Atur ulang filter" aria-label="Atur ulang filter"><i class="bi bi-x-lg"></i></a>
                </div>
            </div>
        </div>
    </form>

    <div class="table-wrap">
        @if ($surats->isEmpty())
            <div class="p-5 text-center text-muted">
                <i class="bi bi-inbox fs-1 d-block mb-2"></i>
                <div class="fw-semibold text-body">Tidak ada surat yang cocok</div>
                <div class="mb-3">Ubah kata kunci atau filter, atau catat surat baru.</div>
                <a href="{{ route('surat.create', ['jenis' => 'masuk']) }}" class="btn btn-primary btn-sm"><i class="bi bi-plus-lg"></i> Catat surat masuk</a>
            </div>
        @else
            <div class="table-responsive">
                <table class="table table-hover align-middle">
                    <thead>
                        <tr>
                            <th>Tanggal</th>
                            <th>Nomor surat</th>
                            <th>Perihal dan pihak</th>
                            <th>Kategori</th>
                            <th>Status</th>
                            <th class="text-end no-print">Berkas</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($surats as $s)
                            @php $telat = $s->belum_ditindak && $s->menunggu_hari > 7; @endphp
                            <tr class="{{ $telat ? 'row-late' : '' }}">
                                <td class="text-nowrap">
                                    {{ $s->tanggal_surat->translatedFormat('j M Y') }}
                                    <span class="muted-s d-block">{{ $s->jenis === 'masuk' ? 'Masuk' : 'Keluar' }}</span>
                                </td>
                                <td class="nomor">
                                    {{ $s->nomor_surat }}
                                    @if ($s->nomor_agenda)
                                        <span class="muted-s d-block">Agenda {{ $s->nomor_agenda }}</span>
                                    @endif
                                </td>
                                <td style="min-width:260px">
                                    <a class="perihal" href="{{ route('surat.show', $s) }}">{{ \Illuminate\Support\Str::limit($s->perihal, 110) }}</a>
                                    <span class="muted-s">
                                        {{ $s->jenis === 'masuk' ? 'Dari' : 'Kepada' }} {{ $s->pihak }}
                                        @if ($s->izinPenelitian)
                                            &ndash; {{ $s->izinPenelitian->nama_mahasiswa }}
                                        @endif
                                    </span>
                                    @if ($s->sifat !== 'biasa')
                                        <span class="pill pill-urgent ms-1">{{ $s->sifat_label }}</span>
                                    @endif
                                </td>
                                <td><span class="pill pill-plain">{{ $s->kategori->nama }}</span></td>
                                <td>
                                    @include('partials.status-pill', ['surat' => $s])
                                    @if ($telat)
                                        <span class="muted-s d-block mt-1">Menunggu {{ $s->menunggu_hari }} hari</span>
                                    @elseif ($s->tindakLanjut)
                                        <span class="muted-s d-block mt-1">{{ $s->tindakLanjut->hasil_label }}</span>
                                    @endif
                                </td>
                                <td class="text-end text-nowrap no-print">
                                    @if ($s->file_path)
                                        <a href="{{ route('berkas.surat', $s) }}" target="_blank" rel="noopener" class="btn btn-sm btn-light-line" title="Buka berkas"><i class="bi bi-eye"></i></a>
                                        <a href="{{ route('berkas.surat', [$s, 'unduh' => 1]) }}" class="btn btn-sm btn-light-line" title="Unduh berkas"><i class="bi bi-download"></i></a>
                                    @endif
                                    <a href="{{ route('surat.show', $s) }}" class="btn btn-sm btn-primary">Detail</a>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>

            <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 p-3 border-top no-print" style="border-color: var(--line) !important">
                <span class="muted-s">Menampilkan {{ $surats->firstItem() }}&ndash;{{ $surats->lastItem() }} dari {{ $surats->total() }} surat</span>
                {{ $surats->links() }}
            </div>
        @endif
    </div>
@endsection
