@php
    /** Variabel: $surat, $kategoris, $induk (boleh null), $mode ('create' | 'edit') */
    $edit = $mode === 'edit';
    $izin = $surat->izinPenelitian;
    $aud = $surat->izinAudiensi;

    $jenisAwal = old('jenis', $surat->jenis ?? 'masuk');
    $kategoriAwal = old('kategori_id', $surat->kategori_id);
    $slugAwal = optional($kategoris->firstWhere('id', (int) $kategoriAwal))->slug;
    $masukAwal = $jenisAwal === 'masuk';

    $v = fn (string $k, $d = null) => old($k, $surat->{$k} ?? $d);
    $tgl = fn (string $k) => old($k, optional($surat->{$k})->format('Y-m-d'));
    $vi = fn (string $k) => old($k, $izin?->{$k});
    $va = fn (string $k) => old($k, $aud?->{$k});
    $tglI = fn (string $k) => old($k, optional($izin?->{$k})->format('Y-m-d'));
    $tglA = fn (string $k) => old($k, optional($aud?->{$k})->format('Y-m-d'));
    $err = fn (string $k) => $errors->has($k) ? 'is-invalid' : '';
@endphp

@if ($errors->any())
    <div class="alert alert-danger" role="alert">
        <div class="fw-semibold mb-1">Surat belum bisa disimpan. Periksa isian berikut:</div>
        <ul class="mb-0 ps-3">
            @foreach ($errors->all() as $pesan)
                <li>{{ $pesan }}</li>
            @endforeach
        </ul>
    </div>
@endif

<form method="POST" enctype="multipart/form-data" id="form-surat"
      action="{{ $edit ? route('surat.update', $surat) : route('surat.store') }}">
    @csrf
    @if ($edit) @method('PUT') @endif

    @if ($induk)
        <input type="hidden" name="surat_asal_id" value="{{ old('surat_asal_id', $surat->surat_asal_id ?? $induk->id) }}">
        <div class="alert alert-warning d-flex gap-2" role="note">
            <i class="bi bi-reply-fill"></i>
            <div>Surat ini adalah balasan untuk <a href="{{ route('surat.show', $induk) }}">{{ $induk->nomor_surat }}</a> ({{ \Illuminate\Support\Str::limit($induk->perihal, 80) }}).</div>
        </div>
    @endif

    {{-- ================= Data surat ================= --}}
    <section class="form-section">
        <div class="hd"><i class="bi bi-file-earmark-text"></i> Data surat</div>
        <div class="bd">
            <div class="row g-3">
                <div class="col-12">
                    <span class="form-label d-block">Jenis surat</span>
                    @if ($edit)
                        <input type="hidden" name="jenis" value="{{ $surat->jenis }}">
                        <span class="pill pill-info">{{ $surat->jenis_label }}</span>
                        <span class="form-text ms-2">Jenis surat tidak bisa diubah setelah disimpan.</span>
                    @else
                        <div class="seg" role="radiogroup" aria-label="Jenis surat">
                            <input type="radio" name="jenis" id="jenis-masuk" value="masuk" {{ $jenisAwal === 'masuk' ? 'checked' : '' }}>
                            <label for="jenis-masuk"><i class="bi bi-box-arrow-in-down"></i> Surat masuk</label>
                            <input type="radio" name="jenis" id="jenis-keluar" value="keluar" {{ $jenisAwal === 'keluar' ? 'checked' : '' }}>
                            <label for="jenis-keluar"><i class="bi bi-box-arrow-up"></i> Surat keluar</label>
                        </div>
                    @endif
                </div>

                <div class="col-md-6">
                    <label class="form-label req" for="kategori_id">Kategori</label>
                    <select name="kategori_id" id="kategori_id" class="form-select {{ $err('kategori_id') }}">
                        <option value="">Pilih kategori</option>
                        @foreach ($kategoris as $k)
                            <option value="{{ $k->id }}" data-slug="{{ $k->slug }}" @selected((string) $kategoriAwal === (string) $k->id)>{{ $k->nama }}</option>
                        @endforeach
                    </select>
                </div>

                <div class="col-md-3">
                    <label class="form-label req" for="sifat">Sifat surat</label>
                    <select name="sifat" id="sifat" class="form-select {{ $err('sifat') }}">
                        @foreach (\App\Models\Surat::SIFAT as $k => $lbl)
                            <option value="{{ $k }}" @selected($v('sifat', 'biasa') === $k)>{{ $lbl }}</option>
                        @endforeach
                    </select>
                </div>

                <div class="col-md-3 only-masuk {{ $masukAwal ? '' : 'd-none' }}">
                    <label class="form-label" for="nomor_agenda">Nomor agenda</label>
                    <input type="text" name="nomor_agenda" id="nomor_agenda" value="{{ $v('nomor_agenda') }}" class="form-control {{ $err('nomor_agenda') }}">
                </div>

                <div class="col-md-6">
                    <label class="form-label req" for="nomor_surat">Nomor surat</label>
                    <input type="text" name="nomor_surat" id="nomor_surat" value="{{ $v('nomor_surat') }}" class="form-control {{ $err('nomor_surat') }}" placeholder="Contoh: 070/123/Bakesbangpol/X/2026">
                </div>

                <div class="col-md-3">
                    <label class="form-label req" for="tanggal_surat">Tanggal surat</label>
                    <input type="date" name="tanggal_surat" id="tanggal_surat" value="{{ $tgl('tanggal_surat') }}" class="form-control {{ $err('tanggal_surat') }}">
                </div>

                <div class="col-md-3 only-masuk {{ $masukAwal ? '' : 'd-none' }}">
                    <label class="form-label" for="tanggal_terima">Tanggal terima</label>
                    <input type="date" name="tanggal_terima" id="tanggal_terima" value="{{ $tgl('tanggal_terima') }}" class="form-control {{ $err('tanggal_terima') }}">
                </div>

                <div class="col-md-8">
                    <label class="form-label req" for="pihak" id="lbl-pihak">{{ $masukAwal ? 'Pengirim (instansi / organisasi / nama)' : 'Tujuan surat' }}</label>
                    <input type="text" name="pihak" id="pihak" value="{{ $v('pihak') }}" class="form-control {{ $err('pihak') }}">
                </div>

                <div class="col-md-4">
                    <label class="form-label" for="jenis_pihak">Jenis pihak</label>
                    <select name="jenis_pihak" id="jenis_pihak" class="form-select {{ $err('jenis_pihak') }}">
                        <option value="">Pilih</option>
                        @foreach (\App\Models\Surat::JENIS_PIHAK as $k => $lbl)
                            <option value="{{ $k }}" @selected($v('jenis_pihak') === $k)>{{ $lbl }}</option>
                        @endforeach
                    </select>
                </div>

                <div class="col-md-6">
                    <label class="form-label" for="kontak">Kontak (telepon / email)</label>
                    <input type="text" name="kontak" id="kontak" value="{{ $v('kontak') }}" class="form-control {{ $err('kontak') }}">
                </div>

                <div class="col-12">
                    <label class="form-label req" for="perihal">Perihal</label>
                    <textarea name="perihal" id="perihal" rows="2" class="form-control {{ $err('perihal') }}">{{ $v('perihal') }}</textarea>
                </div>

                <div class="col-12">
                    <label class="form-label" for="catatan">Catatan internal</label>
                    <textarea name="catatan" id="catatan" rows="2" class="form-control {{ $err('catatan') }}" placeholder="Opsional">{{ $v('catatan') }}</textarea>
                </div>
            </div>
        </div>
    </section>

    {{-- ================= File surat ================= --}}
    <section class="form-section">
        <div class="hd"><i class="bi bi-paperclip"></i> File surat</div>
        <div class="bd">
            <label class="form-label {{ $edit ? '' : 'req' }}" for="file_surat">Scan atau foto surat</label>
            <input type="file" name="file_surat" id="file_surat" accept=".pdf,.jpg,.jpeg,.png" class="form-control {{ $err('file_surat') }}">
            <div class="form-text">
                Format PDF, JPG, atau PNG, maksimal 10 MB.
                @if ($edit && $surat->file_path)
                    Berkas saat ini: <a href="{{ route('berkas.surat', $surat) }}" target="_blank" rel="noopener">{{ $surat->file_name }}</a> ({{ $surat->ukuran_file }}). Kosongkan jika tidak ingin menggantinya.
                @endif
            </div>
        </div>
    </section>

    {{-- ================= Izin penelitian ================= --}}
    <section class="form-section {{ ($masukAwal && $slugAwal === 'izin-penelitian') ? '' : 'd-none' }}" id="sec-penelitian">
        <div class="hd"><i class="bi bi-mortarboard"></i> Data izin penelitian</div>
        <div class="bd">
            <div class="row g-3">
                <div class="col-md-6">
                    <label class="form-label req" for="nama_mahasiswa">Nama mahasiswa</label>
                    <input type="text" name="nama_mahasiswa" id="nama_mahasiswa" value="{{ $vi('nama_mahasiswa') }}" class="form-control {{ $err('nama_mahasiswa') }}">
                </div>
                <div class="col-md-6">
                    <label class="form-label" for="nim">NIM</label>
                    <input type="text" name="nim" id="nim" value="{{ $vi('nim') }}" class="form-control {{ $err('nim') }}">
                </div>
                <div class="col-md-6">
                    <label class="form-label req" for="universitas">Universitas</label>
                    <input type="text" name="universitas" id="universitas" value="{{ $vi('universitas') }}" class="form-control {{ $err('universitas') }}">
                </div>
                <div class="col-md-6">
                    <label class="form-label" for="prodi">Program studi</label>
                    <input type="text" name="prodi" id="prodi" value="{{ $vi('prodi') }}" class="form-control {{ $err('prodi') }}">
                </div>
                <div class="col-md-6">
                    <label class="form-label req" for="penanggung_jawab">Penanggung jawab</label>
                    <input type="text" name="penanggung_jawab" id="penanggung_jawab" value="{{ $vi('penanggung_jawab') }}" class="form-control {{ $err('penanggung_jawab') }}" placeholder="Dosen pembimbing / pejabat kampus">
                </div>
                <div class="col-md-6">
                    <label class="form-label" for="lokasi_penelitian">Lokasi penelitian</label>
                    <input type="text" name="lokasi_penelitian" id="lokasi_penelitian" value="{{ $vi('lokasi_penelitian') }}" class="form-control {{ $err('lokasi_penelitian') }}">
                </div>
                <div class="col-12">
                    <label class="form-label" for="judul_penelitian">Judul penelitian</label>
                    <textarea name="judul_penelitian" id="judul_penelitian" rows="2" class="form-control {{ $err('judul_penelitian') }}">{{ $vi('judul_penelitian') }}</textarea>
                </div>
                <div class="col-md-3">
                    <label class="form-label" for="masa_mulai">Masa penelitian (mulai)</label>
                    <input type="date" name="masa_mulai" id="masa_mulai" value="{{ $tglI('masa_mulai') }}" class="form-control {{ $err('masa_mulai') }}">
                </div>
                <div class="col-md-3">
                    <label class="form-label" for="masa_selesai">Masa penelitian (selesai)</label>
                    <input type="date" name="masa_selesai" id="masa_selesai" value="{{ $tglI('masa_selesai') }}" class="form-control {{ $err('masa_selesai') }}">
                </div>

                <div class="col-md-6"></div>

                <div class="col-md-5">
                    <label class="form-label" for="foto">Foto mahasiswa</label>
                    <input type="file" name="foto" id="foto" accept=".jpg,.jpeg,.png" data-preview="#foto-preview" class="form-control {{ $err('foto') }}">
                    <div class="form-text">JPG atau PNG, maksimal 2 MB. Disarankan foto berlatar polos, rasio 3:4.</div>
                    <div class="mt-2">
                        <img id="foto-preview" alt="Pratinjau foto mahasiswa"
                             class="foto-box {{ ($izin && $izin->foto_path) ? '' : 'd-none' }}"
                             src="{{ ($izin && $izin->foto_path) ? route('berkas.izin', [$izin, 'foto']) : '' }}">
                    </div>
                </div>

                <div class="col-md-7">
                    <span class="form-label d-block">Tanda tangan</span>
                    <div class="sigpad-box">
                        <canvas id="sigpad" aria-label="Area tanda tangan"></canvas>
                        <span class="sigpad-hint">Tanda tangan di sini dengan mouse, jari, atau stylus</span>
                    </div>
                    <input type="hidden" name="ttd_data" id="ttd_data" value="">
                    <div class="d-flex flex-wrap align-items-center gap-2 mt-2">
                        <button type="button" class="btn btn-sm btn-light-line" data-sig-clear><i class="bi bi-eraser"></i> Hapus coretan</button>
                        <span class="form-text m-0">atau unggah gambar:</span>
                        <input type="file" name="ttd_file" accept=".jpg,.jpeg,.png" class="form-control form-control-sm w-auto {{ $err('ttd_file') }}">
                    </div>
                    @if ($izin && $izin->ttd_path)
                        <div class="mt-2">
                            <div class="form-text mb-1">Tanda tangan tersimpan (akan diganti jika Anda membuat yang baru):</div>
                            <img class="ttd-box" alt="Tanda tangan tersimpan" src="{{ route('berkas.izin', [$izin, 'ttd']) }}">
                        </div>
                    @endif
                    @error('ttd_data') <div class="text-danger small mt-1">{{ $message }}</div> @enderror
                </div>
            </div>
        </div>
    </section>

    {{-- ================= Izin audiensi / kunjungan ================= --}}
    <section class="form-section {{ ($masukAwal && $slugAwal === 'izin-audiensi') ? '' : 'd-none' }}" id="sec-audiensi">
        <div class="hd"><i class="bi bi-people"></i> Data audiensi / kunjungan</div>
        <div class="bd">
            <div class="row g-3">
                <div class="col-md-4">
                    <label class="form-label" for="tanggal_rencana">Tanggal rencana kunjungan</label>
                    <input type="date" name="tanggal_rencana" id="tanggal_rencana" value="{{ $tglA('tanggal_rencana') }}" class="form-control {{ $err('tanggal_rencana') }}">
                </div>
                <div class="col-md-4">
                    <label class="form-label" for="jumlah_peserta">Perkiraan jumlah peserta</label>
                    <input type="number" min="1" name="jumlah_peserta" id="jumlah_peserta" value="{{ $va('jumlah_peserta') }}" class="form-control {{ $err('jumlah_peserta') }}">
                </div>
                <div class="col-md-4">
                    <label class="form-label" for="penanggung_jawab_aud">Penanggung jawab / koordinator</label>
                    <input type="text" name="penanggung_jawab" id="penanggung_jawab_aud" value="{{ $va('penanggung_jawab') }}" class="form-control {{ $err('penanggung_jawab') }}">
                </div>
                <div class="col-12">
                    <label class="form-label" for="tujuan">Tujuan kunjungan / audiensi</label>
                    <textarea name="tujuan" id="tujuan" rows="3" class="form-control {{ $err('tujuan') }}">{{ $va('tujuan') }}</textarea>
                </div>
            </div>
        </div>
    </section>

    <div class="d-flex gap-2 mb-4">
        <button type="submit" class="btn btn-primary"><i class="bi bi-check2"></i> {{ $edit ? 'Simpan perubahan' : 'Simpan ke arsip' }}</button>
        <a href="{{ $edit ? route('surat.show', $surat) : route('surat.index') }}" class="btn btn-light-line">Batal</a>
    </div>
</form>

@push('scripts')
    <script src="{{ asset('vendor/signature_pad/signature_pad.umd.min.js') }}"></script>
@endpush
