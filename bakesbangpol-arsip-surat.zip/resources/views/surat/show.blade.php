@extends('layouts.app')

@section('title', $surat->nomor_surat)

@php
    $tl = $surat->tindakLanjut;
    $masuk = $surat->jenis === 'masuk';
    $izin = $surat->izinPenelitian;
    $aud = $surat->izinAudiensi;

    if (! $masuk) {
        $stempelKelas = 'stempel-info'; $stempelTeks = 'Surat keluar'; $stempelKet = $surat->tanggal_surat->translatedFormat('j F Y');
    } elseif ($surat->status === 'sudah_ditindak' && $tl) {
        $stempelKelas = match ($tl->hasil) { 'ditolak' => 'stempel-bad', 'dialihkan' => 'stempel-info', default => 'stempel-ok' };
        $stempelTeks = $tl->hasil_label;
        $stempelKet = $tl->tanggal_tindakan->translatedFormat('j F Y');
    } else {
        $stempelKelas = 'stempel-warn'; $stempelTeks = 'Belum ditindak'; $stempelKet = 'Menunggu ' . $surat->menunggu_hari . ' hari';
    }
@endphp

@section('content')
    <div class="page-head">
        <div>
            <a href="{{ route('surat.index') }}" class="small text-decoration-none"><i class="bi bi-arrow-left"></i> Kembali ke arsip</a>
            <h1 class="mt-1">Detail {{ strtolower($surat->jenis_label) }}</h1>
        </div>
        <div class="d-flex flex-wrap gap-2 no-print">
            @if ($masuk)
                <a href="{{ route('surat.create', ['asal' => $surat->id]) }}" class="btn btn-light-line"><i class="bi bi-reply"></i> Catat surat balasan</a>
            @endif
            <a href="{{ route('surat.edit', $surat) }}" class="btn btn-light-line"><i class="bi bi-pencil"></i> Ubah</a>
            <button type="button" class="btn btn-light-line" onclick="window.print()"><i class="bi bi-printer"></i> Cetak</button>
            @if (auth()->user()->isAdmin())
                <form method="POST" action="{{ route('surat.destroy', $surat) }}" data-confirm="Hapus surat ini dari arsip? Berkasnya tetap tersimpan di server.">
                    @csrf @method('DELETE')
                    <button class="btn btn-outline-danger"><i class="bi bi-trash"></i> Hapus</button>
                </form>
            @endif
        </div>
    </div>

    <div class="row g-4">
        <div class="col-xl-8">
            {{-- ================= Lembar surat ================= --}}
            <article class="lembar mb-4">
                <div class="lembar-head">
                    <div>
                        <div class="no">{{ $surat->nomor_surat }} &ndash; {{ $surat->kategori->nama }}</div>
                        <h2>{{ $surat->perihal }}</h2>
                        <div class="mt-2 d-flex flex-wrap gap-2">
                            <span class="pill pill-plain">{{ $surat->jenis_label }}</span>
                            @if ($surat->sifat !== 'biasa') <span class="pill pill-urgent">{{ $surat->sifat_label }}</span> @endif
                            @if ($surat->jenis_pihak_label) <span class="pill pill-plain">{{ $surat->jenis_pihak_label }}</span> @endif
                        </div>
                    </div>
                    <div class="stempel {{ $stempelKelas }}">{{ $stempelTeks }}<small>{{ $stempelKet }}</small></div>
                </div>

                <div class="lembar-body">
                    <dl class="dl">
                        <dt>Nomor surat</dt><dd>{{ $surat->nomor_surat }}</dd>
                        @if ($surat->nomor_agenda)<dt>Nomor agenda</dt><dd>{{ $surat->nomor_agenda }}</dd>@endif
                        <dt>Tanggal surat</dt><dd>{{ $surat->tanggal_surat->translatedFormat('l, j F Y') }}</dd>
                        @if ($masuk && $surat->tanggal_terima)<dt>Tanggal terima</dt><dd>{{ $surat->tanggal_terima->translatedFormat('l, j F Y') }}</dd>@endif
                        <dt>{{ $masuk ? 'Pengirim' : 'Tujuan' }}</dt><dd>{{ $surat->pihak }}</dd>
                        @if ($surat->kontak)<dt>Kontak</dt><dd>{{ $surat->kontak }}</dd>@endif
                        @if ($surat->catatan)<dt>Catatan internal</dt><dd>{!! nl2br(e($surat->catatan)) !!}</dd>@endif
                        @if ($surat->suratAsal)
                            <dt>Balasan untuk</dt>
                            <dd><a href="{{ route('surat.show', $surat->suratAsal) }}">{{ $surat->suratAsal->nomor_surat }}</a></dd>
                        @endif
                        <dt>Dicatat oleh</dt><dd>{{ $surat->pembuat?->name ?? '-' }}, {{ $surat->created_at->translatedFormat('j M Y H:i') }}</dd>
                    </dl>
                </div>
            </article>

            {{-- ================= Data izin penelitian ================= --}}
            @if ($izin)
                <section class="card mb-4">
                    <div class="card-header"><i class="bi bi-mortarboard me-1"></i> Data izin penelitian</div>
                    <div class="card-body">
                        <div class="d-flex flex-wrap gap-4">
                            <div>
                                @if ($izin->foto_path)
                                    <a href="{{ route('berkas.izin', [$izin, 'foto']) }}" target="_blank" rel="noopener">
                                        <img class="foto-box" alt="Foto {{ $izin->nama_mahasiswa }}" src="{{ route('berkas.izin', [$izin, 'foto']) }}">
                                    </a>
                                @else
                                    <div class="foto-box d-grid place-items-center text-muted small text-center p-2" style="place-items:center">Belum ada foto</div>
                                @endif
                            </div>
                            <dl class="dl flex-fill" style="min-width:260px">
                                <dt>Nama mahasiswa</dt><dd>{{ $izin->nama_mahasiswa }}</dd>
                                @if ($izin->nim)<dt>NIM</dt><dd>{{ $izin->nim }}</dd>@endif
                                <dt>Universitas</dt><dd>{{ $izin->universitas }}</dd>
                                @if ($izin->prodi)<dt>Program studi</dt><dd>{{ $izin->prodi }}</dd>@endif
                                <dt>Penanggung jawab</dt><dd>{{ $izin->penanggung_jawab }}</dd>
                                @if ($izin->judul_penelitian)<dt>Judul penelitian</dt><dd>{{ $izin->judul_penelitian }}</dd>@endif
                                @if ($izin->lokasi_penelitian)<dt>Lokasi</dt><dd>{{ $izin->lokasi_penelitian }}</dd>@endif
                                @if ($izin->masa_mulai || $izin->masa_selesai)
                                    <dt>Masa penelitian</dt>
                                    <dd>{{ optional($izin->masa_mulai)->translatedFormat('j M Y') ?? '?' }} s.d. {{ optional($izin->masa_selesai)->translatedFormat('j M Y') ?? '?' }}</dd>
                                @endif
                                <dt>Tanda tangan</dt>
                                <dd>
                                    @if ($izin->ttd_path)
                                        <img class="ttd-box" alt="Tanda tangan {{ $izin->nama_mahasiswa }}" src="{{ route('berkas.izin', [$izin, 'ttd']) }}">
                                    @else
                                        <span class="text-muted">Belum ada</span>
                                    @endif
                                </dd>
                            </dl>
                        </div>
                    </div>
                </section>
            @endif

            {{-- ================= Data audiensi ================= --}}
            @if ($aud)
                <section class="card mb-4">
                    <div class="card-header"><i class="bi bi-people me-1"></i> Data audiensi / kunjungan</div>
                    <div class="card-body">
                        <dl class="dl mb-0">
                            <dt>Pihak yang berkunjung</dt><dd>{{ $aud->nama_pihak }}</dd>
                            <dt>Jenis pihak</dt><dd>{{ \App\Models\Surat::JENIS_PIHAK[$aud->jenis_pihak] ?? ucfirst($aud->jenis_pihak) }}</dd>
                            @if ($aud->tanggal_rencana)<dt>Tanggal rencana</dt><dd>{{ $aud->tanggal_rencana->translatedFormat('l, j F Y') }}</dd>@endif
                            @if ($aud->jumlah_peserta)<dt>Jumlah peserta</dt><dd>{{ number_format($aud->jumlah_peserta, 0, ',', '.') }} orang</dd>@endif
                            @if ($aud->penanggung_jawab)<dt>Penanggung jawab</dt><dd>{{ $aud->penanggung_jawab }}</dd>@endif
                            @if ($aud->tujuan)<dt>Tujuan</dt><dd>{!! nl2br(e($aud->tujuan)) !!}</dd>@endif
                        </dl>
                    </div>
                </section>
            @endif

            {{-- ================= Berkas surat ================= --}}
            <section class="card">
                <div class="card-header d-flex justify-content-between align-items-center flex-wrap gap-2">
                    <span><i class="bi bi-file-earmark-text me-1"></i> Berkas surat</span>
                    @if ($surat->file_path)
                        <span class="d-flex gap-2 no-print">
                            <a href="{{ route('berkas.surat', $surat) }}" target="_blank" rel="noopener" class="btn btn-sm btn-light-line"><i class="bi bi-box-arrow-up-right"></i> Buka</a>
                            <a href="{{ route('berkas.surat', [$surat, 'unduh' => 1]) }}" class="btn btn-sm btn-primary"><i class="bi bi-download"></i> Unduh</a>
                        </span>
                    @endif
                </div>
                <div class="card-body">
                    @if (! $surat->file_path)
                        <p class="text-muted mb-0">Belum ada berkas yang diunggah.</p>
                    @else
                        <p class="muted-s mb-2">{{ $surat->file_name }} &ndash; {{ $surat->ukuran_file }}</p>
                        @if ($surat->file_is_pdf)
                            <iframe class="doc-frame" title="Pratinjau {{ $surat->nomor_surat }}" src="{{ route('berkas.surat', $surat) }}"></iframe>
                        @elseif ($surat->file_is_image)
                            <img class="doc-img" alt="Berkas surat {{ $surat->nomor_surat }}" src="{{ route('berkas.surat', $surat) }}">
                        @else
                            <p class="text-muted mb-0">Pratinjau tidak tersedia untuk jenis berkas ini. Gunakan tombol Unduh.</p>
                        @endif
                    @endif
                </div>
            </section>
        </div>

        <div class="col-xl-4">
            @if ($masuk)
                {{-- ================= Validasi tindak lanjut ================= --}}
                <section class="card mb-4 no-print">
                    <div class="card-header"><i class="bi bi-patch-check me-1"></i> Validasi tindak lanjut</div>
                    <div class="card-body">
                        @if ($tl)
                            <div class="mb-3">
                                <span class="pill {{ $tl->hasil === 'ditolak' ? 'pill-bad' : ($tl->hasil === 'dialihkan' ? 'pill-info' : 'pill-ok') }}">{{ $tl->hasil_label }}</span>
                            </div>
                            <dl class="dl" style="grid-template-columns: 110px 1fr">
                                <dt>Tanggal</dt><dd>{{ $tl->tanggal_tindakan->translatedFormat('j F Y') }}</dd>
                                @if ($tl->instansi_tujuan)<dt>Dialihkan ke</dt><dd>{{ $tl->instansi_tujuan }}</dd>@endif
                                @if ($tl->keterangan)<dt>Keterangan</dt><dd>{!! nl2br(e($tl->keterangan)) !!}</dd>@endif
                                <dt>Divalidasi</dt><dd>{{ $tl->validator?->name ?? '-' }}</dd>
                            </dl>

                            @if ($surat->balasan->isNotEmpty())
                                <hr>
                                <div class="small fw-semibold mb-1">Surat balasan</div>
                                @foreach ($surat->balasan as $b)
                                    <a class="d-block small" href="{{ route('surat.show', $b) }}"><i class="bi bi-reply"></i> {{ $b->nomor_surat }}</a>
                                @endforeach
                            @endif

                            <form method="POST" action="{{ route('surat.tindak-lanjut.destroy', $surat) }}" class="mt-3"
                                  data-confirm="Batalkan validasi? Surat akan kembali ke status Belum ditindak.">
                                @csrf @method('DELETE')
                                <button class="btn btn-sm btn-outline-danger"><i class="bi bi-arrow-counterclockwise"></i> Batalkan validasi</button>
                            </form>
                        @else
                            <p class="small text-muted">Tindakan atas surat ini dilakukan di luar sistem. Setelah selesai, catat hasilnya di sini.</p>

                            @if ($errors->hasAny(['hasil', 'tanggal_tindakan', 'keterangan', 'instansi_tujuan', 'balasan_nomor', 'balasan_tanggal', 'balasan_file']))
                                <div class="alert alert-danger py-2 small">
                                    <ul class="mb-0 ps-3">
                                        @foreach ($errors->all() as $pesan)<li>{{ $pesan }}</li>@endforeach
                                    </ul>
                                </div>
                            @endif

                            <form method="POST" action="{{ route('surat.tindak-lanjut.store', $surat) }}" enctype="multipart/form-data">
                                @csrf
                                <div class="mb-3">
                                    <label class="form-label req" for="hasil">Surat ini diapakan?</label>
                                    <select name="hasil" id="hasil" class="form-select" data-controls-show>
                                        <option value="">Pilih hasil tindakan</option>
                                        @foreach ($hasilOptions as $k => $lbl)
                                            <option value="{{ $k }}" @selected(old('hasil') === $k)>{{ $lbl }}</option>
                                        @endforeach
                                    </select>
                                </div>

                                <div class="mb-3">
                                    <label class="form-label req" for="tanggal_tindakan">Tanggal tindakan</label>
                                    <input type="date" name="tanggal_tindakan" id="tanggal_tindakan" class="form-control" value="{{ old('tanggal_tindakan', today()->format('Y-m-d')) }}">
                                </div>

                                <div class="mb-3 d-none" data-show-when="dialihkan">
                                    <label class="form-label req" for="instansi_tujuan">Dialihkan ke instansi</label>
                                    <input type="text" name="instansi_tujuan" id="instansi_tujuan" class="form-control" value="{{ old('instansi_tujuan') }}" placeholder="Contoh: Kesbangpol Provinsi Banten">
                                </div>

                                <div class="mb-3">
                                    <label class="form-label" for="keterangan">Keterangan</label>
                                    <textarea name="keterangan" id="keterangan" rows="3" class="form-control" placeholder="Opsional">{{ old('keterangan') }}</textarea>
                                </div>

                                <div class="d-none border rounded-3 p-3 mb-3" data-show-when="dibalas" style="border-color: var(--line) !important; background: var(--surface-2)">
                                    <div class="small fw-semibold mb-2"><i class="bi bi-reply me-1"></i> Surat balasan (opsional)</div>
                                    <div class="mb-2">
                                        <label class="form-label" for="balasan_nomor">Nomor surat balasan</label>
                                        <input type="text" name="balasan_nomor" id="balasan_nomor" class="form-control form-control-sm" value="{{ old('balasan_nomor') }}">
                                    </div>
                                    <div class="mb-2">
                                        <label class="form-label" for="balasan_tanggal">Tanggal surat balasan</label>
                                        <input type="date" name="balasan_tanggal" id="balasan_tanggal" class="form-control form-control-sm" value="{{ old('balasan_tanggal') }}">
                                    </div>
                                    <div>
                                        <label class="form-label" for="balasan_file">File surat balasan</label>
                                        <input type="file" name="balasan_file" id="balasan_file" accept=".pdf,.jpg,.jpeg,.png" class="form-control form-control-sm">
                                        <div class="form-text">Akan tersimpan otomatis sebagai surat keluar yang terhubung ke surat ini.</div>
                                    </div>
                                </div>

                                <button type="submit" class="btn btn-primary w-100"><i class="bi bi-patch-check"></i> Validasi tindak lanjut</button>
                            </form>
                        @endif
                    </div>
                </section>
            @else
                @if ($surat->suratAsal)
                    <section class="card mb-4">
                        <div class="card-header"><i class="bi bi-reply me-1"></i> Surat asal</div>
                        <div class="card-body">
                            <a href="{{ route('surat.show', $surat->suratAsal) }}" class="fw-semibold">{{ $surat->suratAsal->nomor_surat }}</a>
                            <div class="muted-s">{{ \Illuminate\Support\Str::limit($surat->suratAsal->perihal, 120) }}</div>
                        </div>
                    </section>
                @endif
            @endif

            <section class="card no-print">
                <div class="card-header"><i class="bi bi-clock-history me-1"></i> Riwayat pada surat ini</div>
                <div class="card-body">
                    @if ($surat->logs->isEmpty())
                        <p class="text-muted small mb-0">Belum ada riwayat.</p>
                    @else
                        <ul class="timeline mb-0">
                            @foreach ($surat->logs as $log)
                                <li>
                                    <div>{{ $log->keterangan ?? $log->aksi }}</div>
                                    <div class="t">{{ $log->user?->name ?? 'Sistem' }} &ndash; {{ $log->created_at->translatedFormat('j M Y H:i') }}</div>
                                </li>
                            @endforeach
                        </ul>
                    @endif
                </div>
            </section>
        </div>
    </div>
@endsection
