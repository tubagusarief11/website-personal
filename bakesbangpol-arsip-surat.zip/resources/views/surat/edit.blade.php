@extends('layouts.app')

@section('title', 'Ubah Surat')

@section('content')
    <div class="page-head">
        <div>
            <h1>Ubah {{ strtolower($surat->jenis_label) }}</h1>
            <p>{{ $surat->nomor_surat }}</p>
        </div>
    </div>

    @include('surat._form', ['mode' => 'edit'])
@endsection
