@extends('layouts.app')

@section('title', 'Catat Surat')

@section('content')
    <div class="page-head">
        <div>
            <h1>Catat <span id="judul-halaman-jenis">{{ $surat->jenis === 'keluar' ? 'surat keluar' : 'surat masuk' }}</span></h1>
            <p>Simpan salinan surat ke arsip. Surat masuk akan berstatus &ldquo;Belum ditindak&rdquo; sampai tindakannya divalidasi.</p>
        </div>
    </div>

    @include('surat._form', ['mode' => 'create'])
@endsection
