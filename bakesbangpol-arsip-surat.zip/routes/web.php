<?php

use App\Http\Controllers\Admin\UserController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\FileController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\SuratController;
use App\Http\Controllers\TindakLanjutController;
use Illuminate\Support\Facades\Route;

Route::redirect('/', '/dashboard');

/* ------------------------------ Login ------------------------------ */
Route::middleware('guest')->group(function () {
    Route::get('/login', [AuthController::class, 'showLogin'])->name('login');
    Route::post('/login', [AuthController::class, 'login'])->middleware('throttle:10,1')->name('login.attempt');
});

/* ----------------------- Area setelah login ------------------------ */
Route::middleware(['auth', 'active'])->group(function () {
    Route::post('/logout', [AuthController::class, 'logout'])->name('logout');
    Route::get('/dashboard', DashboardController::class)->name('dashboard');

    // Ubah password sendiri
    Route::get('/akun/password', [ProfileController::class, 'editPassword'])->name('password.edit');
    Route::put('/akun/password', [ProfileController::class, 'updatePassword'])->name('password.update');

    // File surat / foto / ttd: hanya bisa dibuka setelah login (tidak ada link publik)
    Route::get('/berkas/surat/{surat}', [FileController::class, 'surat'])->name('berkas.surat');
    Route::get('/berkas/izin-penelitian/{izin}/{jenis}', [FileController::class, 'izinPenelitian'])
        ->whereIn('jenis', ['foto', 'ttd'])
        ->name('berkas.izin');

    // Arsip surat (surat masuk & keluar)
    Route::resource('surat', SuratController::class)
        ->parameters(['surat' => 'surat'])
        ->except(['destroy']);

    // Validasi tindak lanjut surat masuk
    Route::post('/surat/{surat}/tindak-lanjut', [TindakLanjutController::class, 'store'])->name('surat.tindak-lanjut.store');
    Route::delete('/surat/{surat}/tindak-lanjut', [TindakLanjutController::class, 'destroy'])->name('surat.tindak-lanjut.destroy');

    // Khusus admin
    Route::middleware('role:admin')->group(function () {
        Route::delete('/surat/{surat}', [SuratController::class, 'destroy'])->name('surat.destroy');

        Route::prefix('admin')->name('admin.')->group(function () {
            Route::resource('users', UserController::class)->except(['show']);
        });
    });
});
