<?php

namespace App\Providers;

use App\Models\Kategori;
use Carbon\Carbon;
use Illuminate\Pagination\Paginator;
use Illuminate\Support\Facades\View;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        //
    }

    public function boot(): void
    {
        // Zona waktu & bahasa tanggal
        config(['app.timezone' => 'Asia/Jakarta']);
        date_default_timezone_set('Asia/Jakarta');
        Carbon::setLocale('id');

        Paginator::useBootstrapFive();

        // Data sidebar: kategori + jumlah surat masuk yang belum ditindak
        View::composer('layouts.app', function ($view) {
            $kategoriMenu = Kategori::query()
                ->withCount(['surats as belum_count' => function ($q) {
                    $q->where('jenis', 'masuk')->where('status', 'belum_ditindak');
                }])
                ->orderBy('urutan')
                ->get();

            $view->with('kategoriMenu', $kategoriMenu);
        });
    }
}
