<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Database\Eloquent\SoftDeletes;

class Surat extends Model
{
    use SoftDeletes;

    protected $table = 'surats';

    public const JENIS = [
        'masuk' => 'Surat Masuk',
        'keluar' => 'Surat Keluar',
    ];

    public const STATUS = [
        'belum_ditindak' => 'Belum Ditindak',
        'sudah_ditindak' => 'Sudah Ditindak',
    ];

    public const SIFAT = [
        'biasa' => 'Biasa',
        'penting' => 'Penting',
        'segera' => 'Segera',
    ];

    public const JENIS_PIHAK = [
        'instansi' => 'Instansi',
        'mahasiswa' => 'Mahasiswa',
        'ormas' => 'Ormas',
        'lainnya' => 'Lainnya',
    ];

    protected $fillable = [
        'jenis', 'kategori_id', 'nomor_surat', 'nomor_agenda', 'tanggal_surat', 'tanggal_terima',
        'pihak', 'jenis_pihak', 'kontak', 'perihal', 'sifat', 'catatan',
        'file_path', 'file_name', 'file_mime', 'file_size',
        'status', 'surat_asal_id', 'sumber_input', 'template_id', 'created_by',
    ];

    protected function casts(): array
    {
        return [
            'tanggal_surat' => 'date',
            'tanggal_terima' => 'date',
            'file_size' => 'integer',
        ];
    }

    /* ---------------- Relasi ---------------- */

    public function kategori(): BelongsTo
    {
        return $this->belongsTo(Kategori::class);
    }

    public function pembuat(): BelongsTo
    {
        return $this->belongsTo(User::class, 'created_by');
    }

    public function suratAsal(): BelongsTo
    {
        return $this->belongsTo(self::class, 'surat_asal_id');
    }

    public function balasan(): HasMany
    {
        return $this->hasMany(self::class, 'surat_asal_id');
    }

    public function izinPenelitian(): HasOne
    {
        return $this->hasOne(IzinPenelitian::class);
    }

    public function izinAudiensi(): HasOne
    {
        return $this->hasOne(IzinAudiensi::class);
    }

    public function tindakLanjut(): HasOne
    {
        return $this->hasOne(TindakLanjut::class);
    }

    public function logs(): HasMany
    {
        return $this->hasMany(LogAktivitas::class);
    }

    /* ---------------- Accessor ---------------- */

    public function getJenisLabelAttribute(): string
    {
        return self::JENIS[$this->jenis] ?? ucfirst((string) $this->jenis);
    }

    public function getStatusLabelAttribute(): string
    {
        return self::STATUS[$this->status] ?? (string) $this->status;
    }

    public function getSifatLabelAttribute(): string
    {
        return self::SIFAT[$this->sifat] ?? ucfirst((string) $this->sifat);
    }

    public function getJenisPihakLabelAttribute(): ?string
    {
        return $this->jenis_pihak ? (self::JENIS_PIHAK[$this->jenis_pihak] ?? ucfirst($this->jenis_pihak)) : null;
    }

    public function getBelumDitindakAttribute(): bool
    {
        return $this->jenis === 'masuk' && $this->status === 'belum_ditindak';
    }

    /** Berapa hari surat masuk menunggu tindakan (dihitung dari tanggal terima, atau tanggal surat). */
    public function getMenungguHariAttribute(): int
    {
        $acuan = $this->tanggal_terima ?? $this->tanggal_surat;

        return (int) $acuan->copy()->startOfDay()->diffInDays(today(), true);
    }

    public function getFileIsImageAttribute(): bool
    {
        return str_starts_with((string) $this->file_mime, 'image/');
    }

    public function getFileIsPdfAttribute(): bool
    {
        return $this->file_mime === 'application/pdf';
    }

    public function getUkuranFileAttribute(): string
    {
        $b = (int) $this->file_size;
        if ($b >= 1048576) {
            return number_format($b / 1048576, 1, ',', '.') . ' MB';
        }

        return number_format(max($b, 0) / 1024, 0, ',', '.') . ' KB';
    }

    /* ---------------- Scope ---------------- */

    public function scopeFilter(Builder $query, array $f): Builder
    {
        return $query
            ->when($f['jenis'] ?? null, fn (Builder $q, $v) => $q->where('jenis', $v))
            ->when($f['kategori'] ?? null, fn (Builder $q, $v) => $q->whereHas('kategori', fn (Builder $k) => $k->where('slug', $v)))
            ->when($f['status'] ?? null, fn (Builder $q, $v) => $q->where('status', $v))
            ->when($f['tahun'] ?? null, fn (Builder $q, $v) => $q->whereYear('tanggal_surat', $v))
            ->when(trim((string) ($f['q'] ?? '')) !== '', function (Builder $q) use ($f) {
                $kata = '%' . trim((string) $f['q']) . '%';
                $q->where(function (Builder $w) use ($kata) {
                    $w->where('nomor_surat', 'like', $kata)
                        ->orWhere('nomor_agenda', 'like', $kata)
                        ->orWhere('perihal', 'like', $kata)
                        ->orWhere('pihak', 'like', $kata)
                        ->orWhereHas('izinPenelitian', function (Builder $i) use ($kata) {
                            $i->where('nama_mahasiswa', 'like', $kata)
                                ->orWhere('universitas', 'like', $kata)
                                ->orWhere('nim', 'like', $kata);
                        })
                        ->orWhereHas('izinAudiensi', fn (Builder $i) => $i->where('nama_pihak', 'like', $kata));
                });
            });
    }
}
