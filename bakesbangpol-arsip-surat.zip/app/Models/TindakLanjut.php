<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class TindakLanjut extends Model
{
    protected $table = 'tindak_lanjuts';

    public const HASIL = [
        'dibalas' => 'Dibalas',
        'dialihkan' => 'Dialihkan ke instansi lain',
        'diizinkan' => 'Diizinkan / Disetujui',
        'ditolak' => 'Ditolak',
        'diarsipkan' => 'Hanya diarsipkan (informasi)',
    ];

    protected $fillable = [
        'surat_id', 'hasil', 'tanggal_tindakan', 'keterangan', 'instansi_tujuan', 'validator_id',
    ];

    protected function casts(): array
    {
        return [
            'tanggal_tindakan' => 'date',
        ];
    }

    public function surat(): BelongsTo
    {
        return $this->belongsTo(Surat::class);
    }

    public function validator(): BelongsTo
    {
        return $this->belongsTo(User::class, 'validator_id');
    }

    public function getHasilLabelAttribute(): string
    {
        return self::HASIL[$this->hasil] ?? ucfirst((string) $this->hasil);
    }
}
