<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class IzinPenelitian extends Model
{
    protected $table = 'izin_penelitians';

    protected $fillable = [
        'surat_id', 'nama_mahasiswa', 'nim', 'universitas', 'prodi', 'judul_penelitian',
        'lokasi_penelitian', 'penanggung_jawab', 'masa_mulai', 'masa_selesai', 'foto_path', 'ttd_path',
    ];

    protected function casts(): array
    {
        return [
            'masa_mulai' => 'date',
            'masa_selesai' => 'date',
        ];
    }

    public function surat(): BelongsTo
    {
        return $this->belongsTo(Surat::class);
    }
}
