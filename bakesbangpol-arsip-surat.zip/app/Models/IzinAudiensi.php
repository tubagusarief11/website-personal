<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class IzinAudiensi extends Model
{
    protected $table = 'izin_audiensis';

    protected $fillable = [
        'surat_id', 'nama_pihak', 'jenis_pihak', 'tujuan', 'tanggal_rencana',
        'jumlah_peserta', 'penanggung_jawab', 'kontak',
    ];

    protected function casts(): array
    {
        return [
            'tanggal_rencana' => 'date',
            'jumlah_peserta' => 'integer',
        ];
    }

    public function surat(): BelongsTo
    {
        return $this->belongsTo(Surat::class);
    }
}
