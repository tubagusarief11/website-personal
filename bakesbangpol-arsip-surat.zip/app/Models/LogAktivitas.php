<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class LogAktivitas extends Model
{
    protected $table = 'log_aktivitas';

    protected $fillable = ['user_id', 'surat_id', 'aksi', 'keterangan'];

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function surat(): BelongsTo
    {
        return $this->belongsTo(Surat::class);
    }

    /** Catat aktivitas pengguna yang sedang login. */
    public static function catat(string $aksi, ?Surat $surat = null, ?string $keterangan = null): self
    {
        return self::create([
            'user_id' => auth()->id(),
            'surat_id' => $surat?->id,
            'aksi' => $aksi,
            'keterangan' => $keterangan ? mb_substr($keterangan, 0, 500) : null,
        ]);
    }
}
