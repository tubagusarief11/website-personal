<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Kategori extends Model
{
    public const PENELITIAN = 'izin-penelitian';
    public const AUDIENSI = 'izin-audiensi';
    public const LAINNYA = 'lainnya';

    protected $fillable = ['nama', 'slug', 'deskripsi', 'urutan'];

    public function surats(): HasMany
    {
        return $this->hasMany(Surat::class);
    }

    public function getIkonAttribute(): string
    {
        return match ($this->slug) {
            self::PENELITIAN => 'bi-mortarboard',
            self::AUDIENSI => 'bi-people',
            default => 'bi-folder2-open',
        };
    }
}
