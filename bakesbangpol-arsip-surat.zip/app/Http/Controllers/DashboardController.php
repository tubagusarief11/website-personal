<?php

namespace App\Http\Controllers;

use App\Models\Kategori;
use App\Models\LogAktivitas;
use App\Models\Surat;
use Illuminate\View\View;

class DashboardController extends Controller
{
    public function __invoke(): View
    {
        $awalBulan = now()->startOfMonth()->toDateString();

        $ringkas = [
            'total' => Surat::count(),
            'belum' => Surat::where('jenis', 'masuk')->where('status', 'belum_ditindak')->count(),
            'masuk_bulan_ini' => Surat::where('jenis', 'masuk')->whereDate('tanggal_surat', '>=', $awalBulan)->count(),
            'keluar_bulan_ini' => Surat::where('jenis', 'keluar')->whereDate('tanggal_surat', '>=', $awalBulan)->count(),
        ];

        $perKategori = Kategori::query()
            ->withCount([
                'surats as total_count',
                'surats as belum_count' => fn ($q) => $q->where('jenis', 'masuk')->where('status', 'belum_ditindak'),
            ])
            ->orderBy('urutan')
            ->get();

        $antrean = Surat::with('kategori')
            ->where('jenis', 'masuk')
            ->where('status', 'belum_ditindak')
            ->orderByRaw('COALESCE(tanggal_terima, tanggal_surat) asc')
            ->limit(10)
            ->get();

        $terbaru = Surat::with('kategori')->latest('id')->limit(6)->get();

        $aktivitas = LogAktivitas::with(['user', 'surat'])
            ->whereNotIn('aksi', ['login', 'logout'])
            ->latest('id')
            ->limit(6)
            ->get();

        return view('dashboard', compact('ringkas', 'perKategori', 'antrean', 'terbaru', 'aktivitas'));
    }
}
