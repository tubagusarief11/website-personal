<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\LogAktivitas;
use App\Models\User;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use Illuminate\Validation\Rules\Password;
use Illuminate\View\View;

class UserController extends Controller
{
    public function index(): View
    {
        return view('admin.users.index', [
            'users' => User::orderBy('name')->paginate(15),
        ]);
    }

    public function create(): View
    {
        return view('admin.users.create', ['user' => new User(['role' => User::ROLE_OPERATOR, 'is_active' => true])]);
    }

    public function store(Request $request): RedirectResponse
    {
        $v = $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'email' => ['required', 'email', 'max:255', 'unique:users,email'],
            'jabatan' => ['nullable', 'string', 'max:255'],
            'role' => ['required', Rule::in(array_keys(User::ROLES))],
            'password' => ['required', 'confirmed', Password::min(8)],
        ], $this->pesanValidasi(), $this->atributValidasi());

        $user = User::create($v + ['is_active' => $request->boolean('is_active', true)]);

        LogAktivitas::catat('tambah_user', null, 'Pengguna ' . $user->name . ' ditambahkan');

        return redirect()->route('admin.users.index')->with('success', 'Pengguna berhasil ditambahkan.');
    }

    public function edit(User $user): View
    {
        return view('admin.users.edit', compact('user'));
    }

    public function update(Request $request, User $user): RedirectResponse
    {
        $v = $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'email' => ['required', 'email', 'max:255', Rule::unique('users', 'email')->ignore($user->id)],
            'jabatan' => ['nullable', 'string', 'max:255'],
            'role' => ['required', Rule::in(array_keys(User::ROLES))],
            'password' => ['nullable', 'confirmed', Password::min(8)],
        ], $this->pesanValidasi(), $this->atributValidasi());

        $aktif = $request->boolean('is_active');

        // Cegah admin mengunci dirinya sendiri
        if ($user->id === auth()->id() && (! $aktif || $v['role'] !== User::ROLE_ADMIN)) {
            return back()->withInput()->withErrors([
                'role' => 'Anda tidak bisa menonaktifkan akun atau menurunkan peran akun Anda sendiri.',
            ]);
        }

        $data = [
            'name' => $v['name'],
            'email' => $v['email'],
            'jabatan' => $v['jabatan'] ?? null,
            'role' => $v['role'],
            'is_active' => $aktif,
        ];
        if (! empty($v['password'])) {
            $data['password'] = $v['password'];
        }

        $user->update($data);

        LogAktivitas::catat('ubah_user', null, 'Pengguna ' . $user->name . ' diubah');

        return redirect()->route('admin.users.index')->with('success', 'Data pengguna berhasil diperbarui.');
    }

    public function destroy(User $user): RedirectResponse
    {
        if ($user->id === auth()->id()) {
            return back()->withErrors(['hapus' => 'Anda tidak bisa menghapus akun Anda sendiri.']);
        }

        LogAktivitas::catat('hapus_user', null, 'Pengguna ' . $user->name . ' dihapus');
        $user->delete();

        return redirect()->route('admin.users.index')->with('success', 'Pengguna dihapus.');
    }
}
