<?php

namespace App\Http\Controllers;

use App\Models\IzinAudiensi;
use App\Models\IzinPenelitian;
use App\Models\Kategori;
use App\Models\LogAktivitas;
use App\Models\Surat;
use App\Models\TindakLanjut;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;
use Illuminate\View\View;

class SuratController extends Controller
{
    private const FIELD_PENELITIAN = [
        'nama_mahasiswa', 'nim', 'universitas', 'prodi', 'judul_penelitian',
        'lokasi_penelitian', 'penanggung_jawab', 'masa_mulai', 'masa_selesai',
    ];

    private const FIELD_AUDIENSI = [
        'tujuan', 'tanggal_rencana', 'jumlah_peserta', 'penanggung_jawab',
    ];

    /* ===================================================== Daftar / arsip */

    public function index(Request $request): View
    {
        $filter = $request->only(['q', 'jenis', 'kategori', 'status', 'tahun']);

        $surats = Surat::with(['kategori', 'tindakLanjut', 'izinPenelitian', 'izinAudiensi'])
            ->filter($filter)
            ->orderByDesc('tanggal_surat')
            ->orderByDesc('id')
            ->paginate(15)
            ->withQueryString();

        // Jumlah per kategori untuk tab (mengikuti filter lain, kecuali kategori itu sendiri)
        $hitung = Surat::filter(Arr::except($filter, ['kategori']))
            ->selectRaw('kategori_id, count(*) as total')
            ->groupBy('kategori_id')
            ->pluck('total', 'kategori_id');

        $kategoris = Kategori::orderBy('urutan')->get();

        $minTanggal = Surat::min('tanggal_surat');
        $tahunAwal = $minTanggal ? (int) substr((string) $minTanggal, 0, 4) : (int) now()->year;
        $daftarTahun = range((int) now()->year, min($tahunAwal, (int) now()->year));

        return view('surat.index', compact('surats', 'kategoris', 'hitung', 'filter', 'daftarTahun'));
    }

    /* ===================================================== Tambah */

    public function create(Request $request): View
    {
        $jenis = in_array($request->query('jenis'), ['masuk', 'keluar'], true) ? $request->query('jenis') : 'masuk';

        $surat = new Surat([
            'jenis' => $jenis,
            'tanggal_surat' => today(),
            'tanggal_terima' => today(),
            'sifat' => 'biasa',
        ]);

        $induk = null;
        if ($request->filled('asal') && ($induk = Surat::find($request->query('asal')))) {
            $surat->jenis = 'keluar';
            $surat->surat_asal_id = $induk->id;
            $surat->kategori_id = $induk->kategori_id;
            $surat->pihak = $induk->pihak;
            $surat->jenis_pihak = $induk->jenis_pihak;
            $surat->perihal = Str::limit('Balasan: ' . $induk->perihal, 495, '');
        }

        if ($request->filled('kategori')) {
            $kid = Kategori::where('slug', $request->query('kategori'))->value('id');
            if ($kid) {
                $surat->kategori_id = $kid;
            }
        }

        return view('surat.create', [
            'surat' => $surat,
            'induk' => $induk,
            'kategoris' => Kategori::orderBy('urutan')->get(),
        ]);
    }

    public function store(Request $request): RedirectResponse
    {
        $slug = Kategori::whereKey($request->input('kategori_id'))->value('slug');
        $jenis = $request->input('jenis');

        $v = $request->validate(
            $this->aturan($jenis, $slug, true),
            $this->pesanValidasi(),
            $this->atributValidasi()
        );

        $surat = DB::transaction(function () use ($request, $v, $slug) {
            $masuk = $v['jenis'] === 'masuk';

            $data = Arr::only($v, [
                'jenis', 'kategori_id', 'nomor_surat', 'nomor_agenda', 'tanggal_surat', 'pihak',
                'jenis_pihak', 'kontak', 'perihal', 'sifat', 'catatan', 'surat_asal_id',
            ]);
            $data['tanggal_terima'] = $masuk ? ($v['tanggal_terima'] ?? $v['tanggal_surat']) : null;
            $data['status'] = $masuk ? 'belum_ditindak' : 'sudah_ditindak';
            $data['created_by'] = auth()->id();
            $data = array_merge($data, $this->simpanBerkas($request->file('file_surat')));

            $surat = Surat::create($data);
            $this->simpanDataKhusus($surat, $slug, $v, $request);

            LogAktivitas::catat('tambah_surat', $surat, "{$surat->jenis_label} {$surat->nomor_surat} ditambahkan");

            return $surat;
        });

        return redirect()->route('surat.show', $surat)->with('success', 'Surat berhasil disimpan ke arsip.');
    }

    /* ===================================================== Detail */

    public function show(Surat $surat): View
    {
        $surat->load([
            'kategori', 'pembuat', 'suratAsal', 'balasan.kategori',
            'izinPenelitian', 'izinAudiensi', 'tindakLanjut.validator',
            'logs' => fn ($q) => $q->with('user')->latest('id')->limit(10),
        ]);

        return view('surat.show', [
            'surat' => $surat,
            'hasilOptions' => TindakLanjut::HASIL,
        ]);
    }

    /* ===================================================== Ubah */

    public function edit(Surat $surat): View
    {
        $surat->load(['izinPenelitian', 'izinAudiensi', 'suratAsal']);

        return view('surat.edit', [
            'surat' => $surat,
            'induk' => $surat->suratAsal,
            'kategoris' => Kategori::orderBy('urutan')->get(),
        ]);
    }

    public function update(Request $request, Surat $surat): RedirectResponse
    {
        $slug = Kategori::whereKey($request->input('kategori_id'))->value('slug');

        $v = $request->validate(
            $this->aturan($surat->jenis, $slug, false, $surat),
            $this->pesanValidasi(),
            $this->atributValidasi()
        );

        DB::transaction(function () use ($request, $v, $surat, $slug) {
            $masuk = $surat->jenis === 'masuk';

            $data = Arr::only($v, [
                'kategori_id', 'nomor_surat', 'nomor_agenda', 'tanggal_surat', 'pihak',
                'jenis_pihak', 'kontak', 'perihal', 'sifat', 'catatan',
            ]);
            $data['tanggal_terima'] = $masuk ? ($v['tanggal_terima'] ?? $v['tanggal_surat']) : null;

            if ($request->hasFile('file_surat')) {
                $lama = $surat->file_path;
                $data = array_merge($data, $this->simpanBerkas($request->file('file_surat')));
                $this->hapusBerkas($lama);
            }

            $surat->update($data);
            $surat->load(['izinPenelitian', 'izinAudiensi']);
            $this->simpanDataKhusus($surat, $slug, $v, $request);

            LogAktivitas::catat('ubah_surat', $surat, "{$surat->jenis_label} {$surat->nomor_surat} diubah");
        });

        return redirect()->route('surat.show', $surat)->with('success', 'Perubahan surat berhasil disimpan.');
    }

    /* ===================================================== Hapus (admin) */

    public function destroy(Surat $surat): RedirectResponse
    {
        // Soft delete: data dan berkas tetap aman di server, hanya disembunyikan dari arsip.
        LogAktivitas::catat('hapus_surat', $surat, "{$surat->jenis_label} {$surat->nomor_surat} dihapus dari arsip");
        $surat->delete();

        return redirect()->route('surat.index')->with('success', 'Surat dihapus dari arsip.');
    }

    /* ===================================================== Aturan validasi */

    private function aturan(?string $jenis, ?string $slug, bool $baru, ?Surat $surat = null): array
    {
        $aturan = [
            'kategori_id' => ['required', 'exists:kategoris,id'],
            'nomor_surat' => ['required', 'string', 'max:150'],
            'nomor_agenda' => ['nullable', 'string', 'max:50'],
            'tanggal_surat' => ['required', 'date'],
            'tanggal_terima' => ['nullable', 'date'],
            'pihak' => ['required', 'string', 'max:200'],
            'jenis_pihak' => ['nullable', Rule::in(array_keys(Surat::JENIS_PIHAK))],
            'kontak' => ['nullable', 'string', 'max:100'],
            'perihal' => ['required', 'string', 'max:500'],
            'sifat' => ['required', Rule::in(array_keys(Surat::SIFAT))],
            'catatan' => ['nullable', 'string', 'max:2000'],
            'file_surat' => [$baru ? 'required' : 'nullable', 'file', 'mimes:pdf,jpg,jpeg,png', 'max:10240'],
        ];

        if ($baru) {
            $aturan['jenis'] = ['required', Rule::in(['masuk', 'keluar'])];
            $aturan['surat_asal_id'] = ['nullable', 'exists:surats,id'];
        }

        // Data khusus hanya untuk surat MASUK pada kategori yang punya form khusus
        if ($jenis === 'masuk' && $slug === Kategori::PENELITIAN) {
            $aturan += [
                'nama_mahasiswa' => ['required', 'string', 'max:255'],
                'nim' => ['nullable', 'string', 'max:50'],
                'universitas' => ['required', 'string', 'max:255'],
                'prodi' => ['nullable', 'string', 'max:255'],
                'judul_penelitian' => ['nullable', 'string', 'max:2000'],
                'lokasi_penelitian' => ['nullable', 'string', 'max:255'],
                'penanggung_jawab' => ['required', 'string', 'max:255'],
                'masa_mulai' => ['nullable', 'date'],
                'masa_selesai' => ['nullable', 'date', 'after_or_equal:masa_mulai'],
                'foto' => ['nullable', 'file', 'image', 'mimes:jpg,jpeg,png', 'max:2048'],
                'ttd_file' => ['nullable', 'file', 'image', 'mimes:jpg,jpeg,png', 'max:1024'],
                'ttd_data' => ['nullable', 'string', 'max:1500000'],
            ];
        } elseif ($jenis === 'masuk' && $slug === Kategori::AUDIENSI) {
            $aturan += [
                'tujuan' => ['nullable', 'string', 'max:2000'],
                'tanggal_rencana' => ['nullable', 'date'],
                'jumlah_peserta' => ['nullable', 'integer', 'min:1', 'max:100000'],
                'penanggung_jawab' => ['nullable', 'string', 'max:255'],
            ];
        }

        return $aturan;
    }

    /* ===================================================== Berkas */

    /** Tanda tangan dari kanvas (data URL PNG) atau dari file yang diunggah. */
    private function simpanTtd(Request $request): ?string
    {
        $data = (string) $request->input('ttd_data');

        if ($data !== '' && preg_match('#^data:image/png;base64,([A-Za-z0-9+/=]+)$#', $data, $m)) {
            $bin = base64_decode($m[1], true);
            if ($bin !== false && strncmp($bin, "\x89PNG", 4) === 0 && strlen($bin) <= 1048576) {
                $path = 'ttd/' . date('Y/m') . '/' . Str::uuid() . '.png';
                Storage::disk('local')->put($path, $bin);

                return $path;
            }
        }

        if ($request->hasFile('ttd_file')) {
            return $request->file('ttd_file')->store('ttd/' . date('Y/m'), 'local');
        }

        return null;
    }

    /* ===================================================== Data khusus per kategori */

    private function simpanDataKhusus(Surat $surat, ?string $slug, array $v, Request $request): void
    {
        $masuk = $surat->jenis === 'masuk';

        // --- Izin penelitian
        if ($masuk && $slug === Kategori::PENELITIAN) {
            $this->hapusAudiensi($surat);

            $izin = $surat->izinPenelitian ?? new IzinPenelitian();
            $izin->fill(Arr::only($v, self::FIELD_PENELITIAN));
            $izin->surat_id = $surat->id;

            if ($request->hasFile('foto')) {
                $this->hapusBerkas($izin->foto_path);
                $izin->foto_path = $request->file('foto')->store('foto/' . date('Y/m'), 'local');
            }

            if ($ttd = $this->simpanTtd($request)) {
                $this->hapusBerkas($izin->ttd_path);
                $izin->ttd_path = $ttd;
            }

            $izin->save();

            return;
        }

        // --- Izin audiensi / kunjungan
        if ($masuk && $slug === Kategori::AUDIENSI) {
            $this->hapusPenelitian($surat);

            $aud = $surat->izinAudiensi ?? new IzinAudiensi();
            $aud->fill(Arr::only($v, self::FIELD_AUDIENSI));
            $aud->nama_pihak = $surat->pihak;                       // pihak yang berkunjung = pengirim surat
            $aud->jenis_pihak = $v['jenis_pihak'] ?? 'lainnya';
            $aud->kontak = $v['kontak'] ?? null;
            $aud->surat_id = $surat->id;
            $aud->save();

            return;
        }

        // --- Kategori lain / surat keluar: tidak ada data khusus
        $this->hapusPenelitian($surat);
        $this->hapusAudiensi($surat);
    }

    private function hapusPenelitian(Surat $surat): void
    {
        $izin = $surat->izinPenelitian;
        if ($izin) {
            $this->hapusBerkas($izin->foto_path);
            $this->hapusBerkas($izin->ttd_path);
            $izin->delete();
            $surat->unsetRelation('izinPenelitian');
        }
    }

    private function hapusAudiensi(Surat $surat): void
    {
        $aud = $surat->izinAudiensi;
        if ($aud) {
            $aud->delete();
            $surat->unsetRelation('izinAudiensi');
        }
    }
}
