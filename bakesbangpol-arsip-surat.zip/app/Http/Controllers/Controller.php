<?php

namespace App\Http\Controllers;

use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;

abstract class Controller
{
    /** Simpan file surat ke disk privat (storage/app/private) dan kembalikan kolom metadata-nya. */
    protected function simpanBerkas(?UploadedFile $file): array
    {
        if (! $file) {
            return [];
        }

        $mime = $file->getMimeType();
        $ukuran = $file->getSize();
        $nama = Str::limit($file->getClientOriginalName(), 200, '');
        $path = $file->store('surat/' . date('Y/m'), 'local');

        return [
            'file_path' => $path,
            'file_name' => $nama,
            'file_mime' => $mime,
            'file_size' => $ukuran,
        ];
    }

    protected function hapusBerkas(?string $path): void
    {
        if ($path && Storage::disk('local')->exists($path)) {
            Storage::disk('local')->delete($path);
        }
    }

    /** Pesan validasi berbahasa Indonesia (dipakai di seluruh controller). */
    protected function pesanValidasi(): array
    {
        return [
            'required' => ':attribute wajib diisi.',
            'required_if' => ':attribute wajib diisi.',
            'required_with' => ':attribute wajib diisi bila file balasan diunggah.',
            'string' => ':attribute harus berupa teks.',
            'max.string' => ':attribute maksimal :max karakter.',
            'max.file' => 'Ukuran :attribute maksimal :max KB.',
            'max.numeric' => ':attribute maksimal :max.',
            'min.string' => ':attribute minimal :min karakter.',
            'min.numeric' => ':attribute minimal :min.',
            'date' => ':attribute bukan tanggal yang valid.',
            'after_or_equal' => ':attribute tidak boleh sebelum :date.',
            'in' => ':attribute yang dipilih tidak valid.',
            'exists' => ':attribute yang dipilih tidak valid.',
            'integer' => ':attribute harus berupa angka bulat.',
            'file' => ':attribute harus berupa berkas.',
            'mimes' => ':attribute harus berformat: :values.',
            'image' => ':attribute harus berupa gambar.',
            'email' => ':attribute harus berupa alamat email yang valid.',
            'unique' => ':attribute sudah dipakai.',
            'confirmed' => 'Konfirmasi :attribute tidak sama.',
        ];
    }

    /** Nama field yang ramah dibaca pada pesan error. */
    protected function atributValidasi(): array
    {
        return [
            'jenis' => 'Jenis surat',
            'kategori_id' => 'Kategori',
            'nomor_surat' => 'Nomor surat',
            'nomor_agenda' => 'Nomor agenda',
            'tanggal_surat' => 'Tanggal surat',
            'tanggal_terima' => 'Tanggal terima',
            'pihak' => 'Pengirim/Tujuan',
            'jenis_pihak' => 'Jenis pihak',
            'kontak' => 'Kontak',
            'perihal' => 'Perihal',
            'sifat' => 'Sifat surat',
            'catatan' => 'Catatan',
            'file_surat' => 'File surat',
            'surat_asal_id' => 'Surat asal',
            'nama_mahasiswa' => 'Nama mahasiswa',
            'nim' => 'NIM',
            'universitas' => 'Universitas',
            'prodi' => 'Program studi',
            'judul_penelitian' => 'Judul penelitian',
            'lokasi_penelitian' => 'Lokasi penelitian',
            'penanggung_jawab' => 'Penanggung jawab',
            'masa_mulai' => 'Masa penelitian (mulai)',
            'masa_selesai' => 'Masa penelitian (selesai)',
            'foto' => 'Foto mahasiswa',
            'ttd_file' => 'File tanda tangan',
            'ttd_data' => 'Tanda tangan',
            'nama_pihak' => 'Nama pihak yang berkunjung',
            'tujuan' => 'Tujuan kunjungan',
            'tanggal_rencana' => 'Tanggal rencana',
            'jumlah_peserta' => 'Jumlah peserta',
            'hasil' => 'Hasil tindakan',
            'tanggal_tindakan' => 'Tanggal tindakan',
            'keterangan' => 'Keterangan',
            'instansi_tujuan' => 'Instansi tujuan pengalihan',
            'balasan_nomor' => 'Nomor surat balasan',
            'balasan_tanggal' => 'Tanggal surat balasan',
            'balasan_file' => 'File surat balasan',
            'name' => 'Nama',
            'email' => 'Email',
            'password' => 'Password',
            'role' => 'Peran',
            'jabatan' => 'Jabatan',
        ];
    }
}
