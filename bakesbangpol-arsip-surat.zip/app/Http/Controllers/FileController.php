<?php

namespace App\Http\Controllers;

use App\Models\IzinPenelitian;
use App\Models\Surat;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Symfony\Component\HttpFoundation\Response;

/**
 * Semua berkas disimpan di storage/app/private (tidak bisa diakses langsung lewat URL).
 * Berkas hanya dilayani lewat controller ini, dan hanya untuk pengguna yang sudah login.
 */
class FileController extends Controller
{
    public function surat(Request $request, Surat $surat): Response
    {
        abort_unless($surat->file_path && Storage::disk('local')->exists($surat->file_path), 404, 'Berkas tidak ditemukan.');

        return $this->layani($surat->file_path, $surat->file_name ?: basename($surat->file_path), $request->boolean('unduh'));
    }

    public function izinPenelitian(Request $request, IzinPenelitian $izin, string $jenis): Response
    {
        $path = $jenis === 'foto' ? $izin->foto_path : $izin->ttd_path;

        abort_unless($path && Storage::disk('local')->exists($path), 404, 'Berkas tidak ditemukan.');

        return $this->layani($path, basename($path), $request->boolean('unduh'));
    }

    private function layani(string $path, string $nama, bool $unduh): Response
    {
        $disk = Storage::disk('local');
        $headers = [
            'X-Content-Type-Options' => 'nosniff',
            'Cache-Control' => 'private, max-age=0, must-revalidate',
        ];

        if ($unduh) {
            return $disk->download($path, $nama, $headers);
        }

        return $disk->response($path, $nama, $headers);
    }
}
