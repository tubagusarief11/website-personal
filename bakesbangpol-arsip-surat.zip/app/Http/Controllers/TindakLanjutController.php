<?php

namespace App\Http\Controllers;

use App\Models\LogAktivitas;
use App\Models\Surat;
use App\Models\TindakLanjut;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;

class TindakLanjutController extends Controller
{
    /**
     * Validasi hasil tindakan atas surat masuk (tindakan sendiri dilakukan di luar sistem).
     */
    public function store(Request $request, Surat $surat): RedirectResponse
    {
        abort_unless($surat->jenis === 'masuk', 404);

        $v = $request->validate([
            'hasil' => ['required', Rule::in(array_keys(TindakLanjut::HASIL))],
            'tanggal_tindakan' => ['required', 'date'],
            'keterangan' => ['nullable', 'string', 'max:2000'],
            'instansi_tujuan' => ['required_if:hasil,dialihkan', 'nullable', 'string', 'max:255'],
            'balasan_nomor' => ['required_with:balasan_file', 'nullable', 'string', 'max:150'],
            'balasan_tanggal' => ['nullable', 'date'],
            'balasan_file' => ['nullable', 'file', 'mimes:pdf,jpg,jpeg,png', 'max:10240'],
        ], $this->pesanValidasi(), $this->atributValidasi());

        DB::transaction(function () use ($request, $v, $surat) {
            TindakLanjut::updateOrCreate(
                ['surat_id' => $surat->id],
                [
                    'hasil' => $v['hasil'],
                    'tanggal_tindakan' => $v['tanggal_tindakan'],
                    'keterangan' => $v['keterangan'] ?? null,
                    'instansi_tujuan' => $v['hasil'] === 'dialihkan' ? ($v['instansi_tujuan'] ?? null) : null,
                    'validator_id' => auth()->id(),
                ]
            );

            $surat->update(['status' => 'sudah_ditindak']);

            // Bila dibalas dan file surat balasan diunggah -> otomatis jadi surat keluar yang terhubung
            if ($v['hasil'] === 'dibalas' && $request->hasFile('balasan_file')) {
                Surat::create(array_merge([
                    'jenis' => 'keluar',
                    'kategori_id' => $surat->kategori_id,
                    'nomor_surat' => $v['balasan_nomor'],
                    'tanggal_surat' => $v['balasan_tanggal'] ?? $v['tanggal_tindakan'],
                    'pihak' => $surat->pihak,
                    'jenis_pihak' => $surat->jenis_pihak,
                    'perihal' => Str::limit('Balasan: ' . $surat->perihal, 495, ''),
                    'sifat' => 'biasa',
                    'status' => 'sudah_ditindak',
                    'surat_asal_id' => $surat->id,
                    'created_by' => auth()->id(),
                ], $this->simpanBerkas($request->file('balasan_file'))));
            }

            LogAktivitas::catat(
                'validasi_tindak_lanjut',
                $surat,
                'Surat ' . $surat->nomor_surat . ' divalidasi: ' . TindakLanjut::HASIL[$v['hasil']]
            );
        });

        return redirect()->route('surat.show', $surat)->with('success', 'Tindak lanjut surat berhasil divalidasi.');
    }

    /** Batalkan validasi: surat kembali ke status "Belum Ditindak". */
    public function destroy(Surat $surat): RedirectResponse
    {
        abort_unless($surat->jenis === 'masuk', 404);

        DB::transaction(function () use ($surat) {
            $surat->tindakLanjut()?->delete();
            $surat->update(['status' => 'belum_ditindak']);

            LogAktivitas::catat('batal_validasi', $surat, 'Validasi surat ' . $surat->nomor_surat . ' dibatalkan');
        });

        return redirect()->route('surat.show', $surat)->with('success', 'Validasi dibatalkan, surat kembali ke status Belum Ditindak.');
    }
}
