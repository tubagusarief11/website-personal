# BAKESBANGPOL KAB SERANG – Sistem Arsip Surat

Paket ini adalah **kode aplikasi** (overlay) untuk project Laravel 12 baru. Cara pakainya: bikin project Laravel 12 kosong, lalu timpa dengan isi paket ini.

## 1. Buat project Laravel 12

Buka terminal di `C:\xampp\htdocs`, lalu:

```bash
composer create-project laravel/laravel:^12.0 bakesbangpol
```

## 2. Timpa dengan isi paket ini

Ekstrak zip, lalu **copy semua folder/file di dalamnya ke dalam folder `bakesbangpol`**, pilih *Replace* kalau ditanya. File bawaan Laravel yang ikut tertimpa (memang disengaja):

- `bootstrap/app.php`
- `routes/web.php`
- `app/Models/User.php`
- `app/Providers/AppServiceProvider.php`
- `app/Http/Controllers/Controller.php`
- `database/seeders/DatabaseSeeder.php`

## 3. Atur `.env`

```env
APP_NAME="BAKESBANGPOL KAB SERANG"
APP_URL=http://localhost/bakesbangpol/public
APP_LOCALE=id
APP_FALLBACK_LOCALE=id
APP_FAKER_LOCALE=id_ID

DB_CONNECTION=mysql
DB_HOST=127.0.0.1
DB_PORT=3306
DB_DATABASE=bakesbangpol
DB_USERNAME=root
DB_PASSWORD=

SESSION_DRIVER=file
```

Pastikan baris `DB_*` **tidak diawali tanda `#`**. Buat database kosong bernama `bakesbangpol` di phpMyAdmin (collation `utf8mb4_unicode_ci`).

## 4. Jalankan

```bash
cd bakesbangpol
php artisan key:generate
php artisan migrate:fresh --seed
php artisan serve
```

Buka `http://127.0.0.1:8000`.

> Kalau memakai Apache XAMPP (bukan `php artisan serve`), buka `http://localhost/bakesbangpol/public`. Untuk produksi, arahkan *document root* ke folder `public`.

## 5. Akun awal

| Peran | Email | Password |
|---|---|---|
| Admin | `admin@bakesbangpol.local` | `Admin#12345` |
| Operator | `operator@bakesbangpol.local` | `Operator#12345` |

**Wajib ganti password** lewat menu profil (kanan atas) → *Ubah password*, atau ubah/hapus akun lewat menu *Pengguna* (khusus Admin).

## Cara kerja singkat

1. **Catat surat masuk** (Sidebar → *Surat masuk baru*): isi data, upload scan/foto surat. Statusnya otomatis **Belum ditindak**.
2. Kategori **Izin Penelitian Mahasiswa** menampilkan form tambahan: nama, NIM, universitas, prodi, penanggung jawab, judul, lokasi, masa penelitian, **foto**, dan **tanda tangan** (digambar di layar atau upload gambar).
3. Kategori **Izin Audiensi / Kunjungan**: tanggal rencana, jumlah peserta, penanggung jawab, tujuan.
4. Setelah tindakan dilakukan di luar sistem, buka detail surat → **Validasi tindak lanjut**: pilih hasil (Dibalas, Dialihkan, Diizinkan, Ditolak, Hanya diarsipkan), tanggal, keterangan. Statusnya jadi **Sudah ditindak**.
   - *Dibalas* + upload file balasan → otomatis tersimpan sebagai **surat keluar** yang terhubung ke surat asal.
   - *Dialihkan* → wajib isi instansi tujuan.
   - Salah validasi? Klik **Batalkan validasi**.
5. **Arsip**: filter per kategori (tab), status, jenis, tahun, dan pencarian bebas (nomor, perihal, pengirim, nama mahasiswa, universitas, NIM).
6. Surat yang menunggu lebih dari 7 hari diberi penanda kuning/merah di dashboard dan arsip.

## Hak akses

- **Operator**: catat, ubah, validasi surat, lihat arsip.
- **Admin**: semua hak Operator + hapus surat (soft delete, data tidak benar-benar hilang) + kelola pengguna.

## Keamanan berkas

Semua berkas (surat, foto, tanda tangan) disimpan di `storage/app/private`, **bukan** di folder `public`. File hanya bisa dibuka lewat aplikasi setelah login, jadi tidak ada link publik. **Jangan** jalankan `php artisan storage:link` untuk folder ini.

## Backup (penting)

Arsip digital hanya aman kalau ada backup. Minimal rutin salin dua hal ke tempat lain (flashdisk / drive kantor):

1. Folder `storage/app/private`
2. Hasil export database `bakesbangpol` (phpMyAdmin → Export)

## Struktur folder yang ditambahkan

```
app/
  Http/Controllers/
    AuthController.php          login / logout
    DashboardController.php
    SuratController.php         arsip surat + data izin penelitian/audiensi
    TindakLanjutController.php  validasi tindak lanjut
    FileController.php          layani berkas privat (wajib login)
    ProfileController.php       ubah password
    Admin/UserController.php    kelola pengguna
  Http/Middleware/              RoleMiddleware, EnsureUserActive
  Models/                       User, Kategori, Surat, IzinPenelitian,
                                IzinAudiensi, TindakLanjut, LogAktivitas
database/migrations/            7 migrasi (users+role, kategori, surat, dst.)
database/seeders/DatabaseSeeder.php
public/ css, js, img (logo), fonts, vendor (Bootstrap, ikon, signature pad)
resources/views/                layouts, auth, dashboard, surat, admin, profile
routes/web.php
```

Semua aset (Bootstrap, ikon, font) sudah lokal di `public/`, jadi sistem jalan **tanpa internet** dan tanpa `npm`.

## Menyiapkan versi berikutnya

Tabel `surats` sudah punya kolom `sumber_input` dan `template_id` (kosong), dan tabel `tindak_lanjuts` terpisah. Jadi alur disposisi berjenjang (Sekretariat → Kepala Badan → Sekban → bidang) dan generate surat dari template bisa ditambahkan tanpa mengubah struktur arsip.

## Kalau ada error

| Gejala | Penyebab / solusi |
|---|---|
| `Access denied for user` / DB tidak nyambung | Baris `DB_*` di `.env` masih ber-`#`, atau database belum dibuat |
| `sessions` table not found | Pastikan `SESSION_DRIVER=file` |
| Upload gagal untuk file besar | Naikkan `upload_max_filesize` dan `post_max_size` di `php.ini` XAMPP (minimal 12M), restart Apache |
| Halaman tampil tanpa gaya (polos) | `APP_URL` salah, atau akses lewat `/public` yang tidak sesuai. Coba `php artisan serve` |
| Tanggal masih berbahasa Inggris | Jalankan `php artisan optimize:clear` |
